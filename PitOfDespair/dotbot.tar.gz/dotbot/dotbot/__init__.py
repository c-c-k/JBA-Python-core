from .cli import main
from .plugin import Plugin

__version__ = "1.19.2"
