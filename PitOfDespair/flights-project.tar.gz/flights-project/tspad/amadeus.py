import datetime as dt
from pathlib import Path
from pprint import pprint
from time import sleep

import amadeus as am

from jormungand.core.config import config

ROOT = Path(__file__).parent.resolve().joinpath("amadeus")

am_client = am.Client(
        client_id=config['amadeus.key'],
        client_secret=config['amadeus.secret'],
)

SAMPLE_API_CALLS = (
        {
                "name": "airport_and_city_search",
                "api_call": am_client.reference_data.locations.get,
                "params": {
                        "keyword": "r",
                        "subType": am.Location.ANY
                },
                "execute": False,
                "save": False,
        },
        {
                "name": "airport_routes",
                "api_call": am_client.airport.direct_destinations.get,
                "params": {
                        "departureAirportCode": 'TLV'
                },
                "execute": False,
                "save": False,
        },
        {
                "name": "flight_availabilities_search",
                "api_call":
                am_client.shopping.availability.flight_availabilities.post,
                "params": {
                        "originDestinations": [{
                                "id": "1",
                                "originLocationCode": "MIA",
                                "destinationLocationCode": "ATL",
                                "departureDateTime": {
                                        "date": "2022-11-01"
                                }
                        }],
                        "travelers": [{
                                "id": "1",
                                "travelerType": "ADULT"
                        }],
                        "sources": ["GDS"]
                },
                "execute": False,
                "save": False,
        },
        {
                "name": "flight_offers_search",
                "api_call": am_client.shopping.flight_offers_search.get,
                "params": {
                        "originLocationCode": "SYD",
                        "destinationLocationCode": "BKK",
                        "departureDate": "2022-07-01",
                        "adults": 1,
                },
                "execute": True,
                "save": True,
        },
)


def gen_timedated_filename(base_name: str) -> str:
    return (ROOT.joinpath("".join(
            (base_name, "_", dt.datetime.now().strftime("%Y%m%d_%H%M%S"),
             ".json"))))


def execute_api_call(api_call: dict):
    if not api_call["execute"]:
        return
    sleep(0.5)
    try:
        response = api_call["api_call"](**api_call["params"])
    except am.ResponseError as err:
        print(err, err.args)
        print(f"api call: {api_call['name']}")
        return
    if api_call["save"]:
        output_f_path = gen_timedated_filename(api_call['name'])
        with open(output_f_path, "w", encoding="UTF-8") as output_f:
            pprint(response.data, stream=output_f)
    else:
        pprint(response.data)
    return response


def main():
    for sample_api_call in SAMPLE_API_CALLS:
        execute_api_call(sample_api_call)
