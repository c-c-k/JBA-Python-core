def normalize_char_code(char_code: str) -> str:
    return char_code.strip().upper()
