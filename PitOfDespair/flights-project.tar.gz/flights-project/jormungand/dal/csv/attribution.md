# OURAIRPORTS DATASET ATTRIBUTION

Many thanks and kudos to [OurAirports](https://ourairports.com/) for providing the "airports.csv", "regions.csv", "countries.csv" and other airport related datasets freely under public domain license.
