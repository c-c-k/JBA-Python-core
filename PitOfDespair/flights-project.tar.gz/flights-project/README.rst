Jormungand Flight Manager
=========================

A minimal flight management app.

