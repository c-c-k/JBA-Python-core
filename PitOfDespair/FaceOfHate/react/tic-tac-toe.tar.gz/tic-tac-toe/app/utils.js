const winLines = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

export function getGameStatus(winner, xIsNext) {
  const msgWin = "!!! winner: " + winner + "!!!";
  const msgPlay = "Player: " + (xIsNext ? "X" : "O");
  return winner == null ? msgPlay : msgWin;
}

export function calculateWinner(squares) {
  for (let winLine of winLines) {
    const [a, b, c] = winLine;
    if (
      squares[a] !== null &&
      squares[a] === squares[b] &&
      squares[a] === squares[c]
    ) {
      return [squares[a], winLine];
    }
  }
  return [null, null];
}

export function moveDescription(move, isCurrentMove, lastSquare) {
  const prefix = isCurrentMove ? "-> " : "Go to ";
  const suffix =
    move == 0
      ? "game start"
      : `move #${move + 1} (${moveCoord(lastSquare)})`;
  return prefix + suffix;
}

function moveCoord(square) {
  const coord =
    square == null ? [null, null] : [Math.floor(square / 3), square % 3];
  return `row ${coord[0] + 1}, col ${coord[1] + 1}`;
}
