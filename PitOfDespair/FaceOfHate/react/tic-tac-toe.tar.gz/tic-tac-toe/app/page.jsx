"use client";
import { useState } from "react";
import { calculateWinner, moveDescription, getGameStatus } from "./utils";

export default function Game() {
  const [history, setHistory] = useState([
    { squares: Array(9).fill(null), squareIndex: null },
  ]);
  const [currentMove, setCurrentMove] = useState(0);

  const xIsNext = currentMove % 2 == 0;
  console.log(history);
  const currentSquares = history[currentMove].squares;

  function handlePlay(squares, squareIndex) {
    setHistory([
      ...history.slice(0, currentMove + 1),
      { squares: squares, squareIndex: squareIndex },
    ]);
    setCurrentMove(currentMove + 1);
  }

  return (
    <>
      <div className="game">
        <div className="game-board">
          <Board
            xIsNext={xIsNext}
            squares={currentSquares}
            onPlay={handlePlay}
          />
        </div>
        <div className="game-info">
          <GameInfo setCurrentMove={setCurrentMove} history={history} />
        </div>
      </div>
    </>
  );
}

function Board({ xIsNext, squares, onPlay }) {
  const [winner, winLine] = calculateWinner(squares);
  const gameStatus = getGameStatus(winner, xIsNext);

  const rows = [0, 1, 2].map((row) => <Row key={row} row={row} />);

  function handleClick(squareIndex) {
    if (winner || squares[squareIndex]) {
      return;
    }
    const nextSquares = squares.slice();
    nextSquares[squareIndex] = xIsNext ? "X" : "O";
    onPlay(nextSquares, squareIndex);
  }

  function Row({ row }) {
    const columns = [0, 1, 2].map((column) => (
      <Column key={column} column={column} row={row} />
    ));
    return <div className="board-row">{columns}</div>;
  }

  function Column({ row, column }) {
    const cell = row * 3 + column;
    return (
      <Square
        value={squares[cell]}
        onSquareClick={() => handleClick(cell)}
        winSquare={winLine && winLine.includes(cell)}
      />
    );
  }

  return (
    <>
      <div className="status">{gameStatus}</div>
      {rows}
    </>
  );
}

function Square({ value, onSquareClick, winSquare }) {
  const squareClass = winSquare ? "square win-square" : "square";
  return (
    <button className={squareClass} onClick={onSquareClick}>
      {value}
    </button>
  );
}

function GameInfo({ setCurrentMove, history }) {
  const [ascending, setAscending] = useState(true);

  const jumpTo = (nextMoveIndex) => setCurrentMove(nextMoveIndex);

  const moves = history.map((historyEntry, move) => (
    <li key={move}>
      <HistorySubComponent move={move} squareIndex={historyEntry.squareIndex} />
    </li>
  ));

  const RadioSortOrder = () => (
    <>
      <label htmlFor="asc">ascending</label>
      <input
        type="radio"
        name="sort"
        id="asc"
        onChange={() => setAscending(true)}
        checked={ascending}
      />
      <label htmlFor="des">descending</label>
      <input
        type="radio"
        name="sort"
        id="dec"
        onChange={() => setAscending(false)}
        checked={!ascending}
      />
    </>
  );

  function HistorySubComponent({ move, squareIndex }) {
    const isCurrentMove = move == history.length - 1;
    const description = moveDescription(move, isCurrentMove, squareIndex);

    const HistoryParagraph = <p>{description}</p>;
    const HistoryGoToButton = (
      <button onClick={() => jumpTo(move)}>{description}</button>
    );

    return isCurrentMove ? HistoryParagraph : HistoryGoToButton;
  }

  return (
    <>
      <RadioSortOrder />
      <ul>{ascending ? moves : moves.reverse()}</ul>
    </>
  );
}
