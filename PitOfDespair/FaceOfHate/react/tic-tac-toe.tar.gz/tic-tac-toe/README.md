# TicTacToe

A minimal implementation of the [React TicTacToe tutorial].

[React TicTacToe tutorial]: https://react.dev/learn/tutorial-tic-tac-toe
