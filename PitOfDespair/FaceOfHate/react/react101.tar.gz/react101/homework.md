Wed 31 May 2023 21:21:03 IDT
    - do a table:
        - table is component
            - row is component
            - row contains username, mark
                - mark is component - colorize per grade group
            - total average row
        - demo dataset

Sun 04 Jun 2023 21:07:10 IDT
    - do a button that changes color on each click
