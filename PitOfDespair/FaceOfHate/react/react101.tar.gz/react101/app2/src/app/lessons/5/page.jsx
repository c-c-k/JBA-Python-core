"use client";
import Temp from "./components/Temp.jsx";

export default function page() {
    return <Temp />
}
