"use client";
import ClickMe from "./components/ClickMe.jsx";

export default function page() {
    return <ClickMe />
}
