export const tableData = [
  {
    id: "row_1",
    col_1: "row 1 col 1",
    col_2: "row 1 col 2",
    col_3: "row 1 col 3",
    col_4: "row 1 col 4",
  },
  {
    id: "row_2",
    col_1: "row 2 col 1",
    col_2: "row 2 col 2",
    col_3: "row 2 col 3",
    col_4: "row 2 col 4",
  },
  {
    id: "row_3",
    col_1: "row 3 col 1",
    col_2: "row 3 col 2",
    col_3: "row 3 col 3",
    col_4: "row 3 col 4",
  },
  {
    id: "row_4",
    col_1: "row 4 col 1",
    col_2: "row 4 col 2",
    col_3: "row 4 col 3",
    col_4: "row 4 col 4",
  },
];
