"use client";
import TableWithForm from "./components/TableWithForm.jsx";

export default function page() {
    return <TableWithForm />
}
