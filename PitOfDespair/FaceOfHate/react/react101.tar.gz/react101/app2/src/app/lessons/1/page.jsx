"use client";
import GradesTable from "./components/GradesTable.jsx";

export default function page() {
    return <GradesTable />
}
