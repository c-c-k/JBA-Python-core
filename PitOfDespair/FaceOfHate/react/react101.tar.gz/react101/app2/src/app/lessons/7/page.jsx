"use client";
import ThumbnailsGrid from "./components/ThumbnailsGrid.jsx";

export default function page() {
    return <ThumbnailsGrid />
}
