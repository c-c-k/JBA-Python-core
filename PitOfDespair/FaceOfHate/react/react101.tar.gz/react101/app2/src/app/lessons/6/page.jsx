"use client";
import HotelsInfo from "./components/HotelsInfo.jsx";

export default function page() {
    return <HotelsInfo />
}
