"use client";
import KeyChange from "./components/KeyChange.jsx";

export default function page() {
    return <KeyChange />
}
