# JBM-FSP-Programming-Foundations

This Repository contains my solutions to the questions, homework assignments and projects in the **Programming Foundations** module of the **Fullstack Python** course of the **John Bryce - Mediatech** college.



GRRRR .. it's annoying and shameful but I'm dropping this module, it's taking too much time and .. it's just.. not here .. not there .. it's been a very long time since I've learned C++ and Java and a while before I'm intent on relearning them again.. flowcharts are useful but I need to choose and learn some good modeling software in order to make them quickly, efficiently and elegantly otherwise it's just a lot of time wasted on trying to manually making everything fit in place .. and the problems themselves are somewhat challenging and interesting but .. there is just so much other more useful stuff to learn, practice and do....
