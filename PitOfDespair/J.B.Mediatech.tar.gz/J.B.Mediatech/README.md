# John Bryce Mediatech studies repository.

This Repository contains a mixed pasta dish of my solutions to the questions, homework assignments and projects for my studies in the **John Bryce - Mediatech** college.
