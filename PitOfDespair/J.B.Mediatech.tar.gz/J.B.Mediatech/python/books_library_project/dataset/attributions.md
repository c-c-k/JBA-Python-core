* The classics dataset was taken from: https://corgis-edu.github.io/corgis/csv/classics/
* The customers-100.csv was taken from: https://github.com/datablist/sample-csv-files