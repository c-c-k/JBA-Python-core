-- Create tables
-- -------------
CREATE TABLE "student" (
    stud_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    fname VARCHAR(255) NOT NULL,
    lname VARCHAR(255) NOT NULL,
    gender TINYINT NOT NULL ,
    age INTEGER NOT NULL,
    contact_add VARCHAR(255) NOT NULL,
    stud_email VARCHAR(255) NOT NULL,
    stud_pass VARCHAR(255) NOT NULL
);
CREATE TABLE "instructor" (
    ins_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    fname VARCHAR(255) NOT NULL,
    lname VARCHAR(255) NOT NULL,
    gender TINYINT NOT NULL ,
    age INTEGER NOT NULL,
    contact_add VARCHAR(255) NOT NULL,
    ins_email VARCHAR(255) NOT NULL,
    ins_pass VARCHAR(255) NOT NULL
);
CREATE TABLE "transaction" (
    trans_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    trans_name VARCHAR(255) NOT NULL,
    stud_id INTEGER,
    FOREIGN KEY (stud_id)
        REFERENCES "student" (stud_id)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    trans_date
);
CREATE TABLE "courses" (
    course_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    course_name VARCHAR(255) NOT NULL,
    course_desc VARCHAR(255) NOT NULL,
    school_yr
);
CREATE TABLE "subjects" (
    sub_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255) NOT NULL,
    course_id INTEGER,
    FOREIGN KEY (course_id)
        REFERENCES "courses" (course_id)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
);
CREATE TABLE "schedules" (
    sched_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER,
    FOREIGN KEY (course_id)
        REFERENCES "courses" (course_id)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    ins_id INTEGER,
    FOREIGN KEY (ins_id)
        REFERENCES "instructor" (ins_id)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    sub_id INTEGER,
    FOREIGN KEY (sub_id)
        REFERENCES "subjects" (sub_id)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    stud_id INTEGER,
    FOREIGN KEY (stud_id)
        REFERENCES "student" (stud_id)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    day,
    time_start,
    time_end
);
