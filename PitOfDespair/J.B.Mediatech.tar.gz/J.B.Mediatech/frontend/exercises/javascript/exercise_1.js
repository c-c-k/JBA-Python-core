let testString;
let testArray; // = Array();

// Question 1
console.log("Question 1:");
function checkEmail(email) {
    if (
        (email.lastIndexOf("@") !== email.indexOf("@"))
        || email.startsWith("@") || email.endsWith("@")
    ) {
        return `X ${email} is not a valid email.`;
    } else {
        return `V ${email} is a valid email.`;
    }
}
testArray = ["good@email.com", "bad@@email.com", "@bad.email.com", "bad.email.com@"];
testArray.forEach(testString => console.log(checkEmail(testString)))

//Question 2
console.log("Question 2:");
const subStringInfo = (baseString, startIndex, substrLength) => {
   return `In the string "${baseString} the substring of length ${substrLength}`
    + ` starting from index ${startIndex}`
    +` is ${baseString.substring(startIndex, startIndex + substrLength)}`
};
testString = "busdriver"
console.log(subStringInfo(testString, 3, 6))

//Question 3
console.log("Question 3:");
const reverseWordOrder = function(sentence) {
    let words = sentence.split(" ");
    return words.reverse().join(" ");
};
testString = "dark side! the to leads hatred hatred, to leads anger anger, to leads fear"
console.log(reverseWordOrder(testString));

//Question 4
console.log("Question 4:");
const BOOKS_LIST = ["Dune", "The Hobbit", "Starship Troopers", "Accelerando", "Hamlet"];
for ( let book of ["Hamlet", "Tempest"]) { console.log(checkBook(book))}
function checkBook(book) {
    let checkBookResult = (BOOKS_LIST.indexOf(book) >= 0) ? "in" : "not in";
    return `${book} is ${checkBookResult} the books collection of (${BOOKS_LIST.join(", ")})`
}
