# books-library
This is the summary project for the "Python Fundamentals" section of John Bryce mediatech's "Python Fullstack" course.  
It's goal is to build a simple and minimalistic book-library management system.
