# books-library

This project started as the summary project for the "Python Fundamentals" section of John Bryce mediatech's "Python Fullstack" course. 
Currently, it was switched to MDNs' ["Local Library" tutorial](https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django/Tutorial_local_library_website).
The project's goal is to build a simple and minimalistic local book library management system.

## Attributions 

* DylanCastillo, [Kaggle](https://www.kaggle.com/datasets/dylanjcastillo/7k-books-with-metadata) for the 7k books dataset.