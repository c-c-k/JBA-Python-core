from pydantic import BaseModel
from pydantic import EmailStr
from pydantic import model_validator

from fp.validation.model_config import AUTH_GENERAL_CONFIG


class AuthTokenModel(BaseModel):
    model_config = AUTH_GENERAL_CONFIG

    access_token: str
    token_type: str


class AuthTokenDataModel(BaseModel):
    model_config = AUTH_GENERAL_CONFIG

    username: str | None = None


class AuthUserModel(BaseModel):
    model_config = AUTH_GENERAL_CONFIG

    username: str
    email: EmailStr | None = None
    first_name: str | None = None
    last_name: str | None = None
    disabled: bool | None = None


class AuthUserInDBModel(AuthUserModel):
    hashed_password: str


class AuthUserRegistrationModel(AuthUserModel):
    password1: str
    password2: str

    @model_validator(mode='after')
    def check_passwords_match(self) -> 'AuthUserRegistrationModel':
        pw1 = self.password1
        pw2 = self.password2
        if pw1 is not None and pw2 is not None and pw1 != pw2:
            raise ValueError('passwords do not match')
        return self
