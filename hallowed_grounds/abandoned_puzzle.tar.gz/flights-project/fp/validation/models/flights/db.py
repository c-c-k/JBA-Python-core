"""Pydantic validation models mongodb documents

"""
from datetime import datetime
from typing import Any

from pydantic import BaseModel

from fp.validation.annotated_fields import (
        IATACodeField, MongodbIdField, StrIsoDateField)
from fp.validation.model_config import MONGODB_DOCUMENT_MODEL_CONFIG
from fp.validation.models.amadeus import (
        AmadeusFlightOfferModel, AmadeusBookingRequirementsModel,
        AmadeusFlightConfirmResponseDataModel)


class FlightsDBBookingModel(BaseModel):
    model_config = MONGODB_DOCUMENT_MODEL_CONFIG

    id_: MongodbIdField = None
    flight_id: Any
    amadeus_confirm_data: AmadeusFlightConfirmResponseDataModel


class FlightsDBFlightModel(BaseModel):
    model_config = MONGODB_DOCUMENT_MODEL_CONFIG

    id_: MongodbIdField = None
    origin: IATACodeField
    destination: IATACodeField
    departure_date: StrIsoDateField
    return_date: StrIsoDateField | None = None
    amadeus_search_info: AmadeusFlightOfferModel
    amadeus_last_update_search_info: datetime
    amadeus_booking_requirements: AmadeusBookingRequirementsModel | None = None
    amadeus_last_update_booking_requirements: datetime | None = None
    is_current: bool = True
    is_valid: bool = True
