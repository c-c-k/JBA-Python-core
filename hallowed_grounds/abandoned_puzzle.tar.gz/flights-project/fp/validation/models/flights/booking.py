"""Pydantic validation models for flight info

"""
from datetime import datetime

from pydantic import BaseModel, EmailStr

from fp.validation.annotated_fields import IdField
from fp.validation.model_config import FLIGHTS_GENERAL_CONFIG
from .flight import FlightsBaseInfoModel


class FlightsUserInfoModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    first_name: str
    last_name: str
    email_address: EmailStr


class FlightsOrderInfoModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    reference: str
    creation_date: datetime
    origin_system_code: str


class FlightsBookingInfoModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    id_: IdField
    flight_info: FlightsBaseInfoModel
    user_info: FlightsUserInfoModel
    order_info: FlightsOrderInfoModel
