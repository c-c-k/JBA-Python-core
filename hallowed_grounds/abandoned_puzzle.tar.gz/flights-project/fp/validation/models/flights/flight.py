"""Pydantic validation models for flight info

"""
from datetime import date

from pydantic import BaseModel

from fp.validation.annotated_fields import (IATACodeField, MonetaryCostField,
                                            IdField, StrIsoDateField)
from fp.validation.model_config import FLIGHTS_GENERAL_CONFIG
from fp.validation.models.amadeus import AmadeusBookingRequirementsModel


class FlightsBaseInfoModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    id_: IdField
    origin: IATACodeField
    destination: IATACodeField
    departure_date: StrIsoDateField
    return_date: StrIsoDateField | None = None
    price: MonetaryCostField
    currency: str


class FlightDetailsModel(FlightsBaseInfoModel):
    booking_requirements: AmadeusBookingRequirementsModel
