"""Pydantic validation models for flights API requests

"""
from datetime import datetime

from pydantic import BaseModel, model_validator

from fp.validation.annotated_fields import (
        IATACodeField,
        StrIsoDateField,
        IdField,
)
from fp.validation.model_config import FLIGHTS_GENERAL_CONFIG


class FlightsSearchGetModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    origin: IATACodeField
    destination: IATACodeField
    departure_date: StrIsoDateField
    return_date: StrIsoDateField | None = None

    @model_validator(mode="after")
    def origin_different_from_destination(self):
        if (self.origin is not None) and (self.destination is not None):
            if self.origin == self.destination:
                raise ValueError(
                        "Origin and destination airports can't be the same")
        return self

    @model_validator(mode="after")
    def no_departure_before_return(self):
        if (self.departure_date is not None) and (self.return_date
                                                  is not None):
            departure_date = datetime.strptime(self.departure_date, "%Y-%m-%d")
            return_date = datetime.strptime(self.return_date, "%Y-%m-%d")
            if departure_date > return_date:
                raise ValueError("Departure date can't precede return date")
        return self


class FlightsDetailsGetModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    id_: IdField


class FlightsBookingPostModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    id_: IdField
