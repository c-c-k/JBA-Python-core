"""Pydantic validation models for flights API responses

"""
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from fp.validation.model_config import FLIGHTS_GENERAL_CONFIG
from .flight import FlightsBaseInfoModel
from .booking import FlightsBookingInfoModel


class FlightsListResponseModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    type_: Annotated[Literal["flight-offers-info"],
                     Field(alias="type")] = "flight-offers-info"
    flight_offers: list[FlightsBaseInfoModel]


class FlightsBookingResponseModel(BaseModel):
    model_config = FLIGHTS_GENERAL_CONFIG

    type_: Annotated[Literal["flight-booking-info"],
                     Field(alias="type")] = "flight-booking-info"
    data: FlightsBookingInfoModel
