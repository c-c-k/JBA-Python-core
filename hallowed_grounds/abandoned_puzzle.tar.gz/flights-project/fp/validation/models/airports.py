"""Pydantic validation models for OurAirports data
"""
from typing import Annotated

from pydantic import BaseModel, Field, ConfigDict

from fp.validation.annotated_fields import (IATACodeField, CountryCodeField,
                                            NameMin2Field)


class AirportBasicQueryModel(BaseModel):
    """Validator for basic airport search queries.

    .. note::
        The only accepted characters are unicode alphanumeric characters
        and unicode whitespaces. This is fairly restrictive as it precludes
        someone from e.g. copy-pasting a name that contains punctuation,
        however properly addressing such a usecase would require a smart
        search algorithm that would be able to handle different spellings
        for the same name, which is out of scope for this project at the
        moment.

    :query: The query string to be validated
    """
    query: Annotated[str, Field(pattern=r"(?u)[\w\s]{2,64}")]


class AirportShortInfoModel(BaseModel):
    """Brief airport information meant for basic search results.

    :country_code: country code of the country that hosts the airport.
    :iata_code: aiport IATA code.
    :country_name: country name of the country that hosts the airport.
    :municipality: name of the municipality that hosts the airport.
    :name: airport name.
    """
    model_config = ConfigDict(extra="ignore")

    country_code: CountryCodeField
    iata_code: IATACodeField
    country_name: str = NameMin2Field
    municipality: str = NameMin2Field
    name: str = NameMin2Field
