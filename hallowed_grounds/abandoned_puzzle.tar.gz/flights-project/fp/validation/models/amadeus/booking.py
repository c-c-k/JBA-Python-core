from datetime import datetime

from pydantic import BaseModel, EmailStr

from fp.validation.annotated_fields import IdField, StrIsoDateField
from fp.validation.model_config import AMADEUS_RESPONSE_CONFIG


class AmadeusAssociatedRecordModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    reference: str
    creation_date: datetime
    origin_system_code: str
    flight_offer_id: str


class AmadeusTravelerNameModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    first_name: str = "Ivan"
    last_name: str = "Itzik"


class AmadeusTravelerDocumentsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    number: str = "00000000"
    issuance_date: StrIsoDateField = "2014-04-14"
    expiry_date: StrIsoDateField = "2025-04-14"
    issuance_country: str = "IL"
    validity_country: str = "IL"
    issuance_location: str = "TelAviv"
    nationality: str = "IL"
    birth_place: str = "TelAviv"
    document_type: str = "PASSPORT"
    holder: bool = True


class AmadeusTravelerPhoneModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    device_type: str = "MOBILE"
    country_calling_code: str = "972"
    number: str = "31234567"


PLACEHOLDER_TRAVELER_PHONES = [AmadeusTravelerPhoneModel()]


class AmadeusTravelerContactModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    purpose: str = "STANDARD"
    phones: list[AmadeusTravelerPhoneModel] = PLACEHOLDER_TRAVELER_PHONES
    email_address: EmailStr = "ivan_itzik@egged.co.il"


PLACEHOLDER_TRAVELER_NAME = AmadeusTravelerNameModel()
PLACEHOLDER_TRAVELER_CONTACT = AmadeusTravelerContactModel()
PLACEHOLDER_TRAVELER_DOCUMENTS = AmadeusTravelerDocumentsModel()


class AmadeusTravelerModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    id_: IdField = "1"
    date_of_birth: StrIsoDateField = "1980-01-01"
    gender: str = "MALE"
    name: AmadeusTravelerNameModel = PLACEHOLDER_TRAVELER_NAME
    documents: list[AmadeusTravelerDocumentsModel] = [
            PLACEHOLDER_TRAVELER_DOCUMENTS
    ]
    contact: AmadeusTravelerContactModel = (PLACEHOLDER_TRAVELER_CONTACT)


PLACEHOLDER_OPTION = "DELAY_TO_CANCEL"
PLACEHOLDER_DELAY = "6D"


class AmadeusTicketingAgreementsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    option: str = PLACEHOLDER_OPTION
    delay: str = PLACEHOLDER_DELAY


class AmadeusAutomatedProcessModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    code: str
    queue: dict
    office_id: str


class AmadeusTravelerAddressModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    lines: list[str] = ["Golomov, 14"]
    postal_code: str = "12345678900"
    country_code: str = "IL"
    city_name: str = "TelAviv"


PLACEHOLDER_CONTACT_ADDRESSEE = AmadeusTravelerNameModel()
PLACEHOLDER_CONTACT_ADDRESS = AmadeusTravelerAddressModel()
PLACEHOLDER_CONTACT_PHONES = [AmadeusTravelerPhoneModel()]


class AmadeusContactModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    addressee_name: AmadeusTravelerNameModel = PLACEHOLDER_CONTACT_ADDRESSEE
    address: AmadeusTravelerAddressModel = PLACEHOLDER_CONTACT_ADDRESS
    purpose: str = "STANDARD"
    phones: list[AmadeusTravelerPhoneModel] = PLACEHOLDER_CONTACT_PHONES
    company_name: str = "NONE"
    email_address: EmailStr = "ivan_itzik@egged.co.il"
