from typing import Annotated, Literal

from pydantic import BaseModel, Field

from fp.validation.annotated_fields import IdField
from fp.validation.model_config import AMADEUS_RESPONSE_CONFIG
from .booking import (AmadeusAssociatedRecordModel, AmadeusTravelerModel,
                      AmadeusTicketingAgreementsModel,
                      AmadeusAutomatedProcessModel, AmadeusContactModel)
from .flight import AmadeusFlightOfferModel, AmadeusBookingRequirementsModel


class AmadeusResponseMetaModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    count: int
    links: dict[str, str]


class AmadeusDictionariesModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    locations: dict[str, dict[str, str]] | None = None
    aircraft: dict[str, str] | None = None
    currencies: dict[str, str] | None = None
    carriers: dict[str, str] | None = None


class AmadeusWarningModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    status: int
    code: int
    title: str
    detail: str


class AmadeusBaseResponseModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    warnings: list[AmadeusWarningModel] | None = None
    meta: AmadeusResponseMetaModel | None = None
    data: BaseModel | list[BaseModel] | None = None
    dictionaries: AmadeusDictionariesModel | None = None


class AmadeusFlightsSearchResponseModel(AmadeusBaseResponseModel):
    data: list[AmadeusFlightOfferModel]


class AmadeusFlightsPricingResponseDataModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    type_: Annotated[Literal["flight-offers-pricing"], Field(alias="type")]
    flight_offers: list[AmadeusFlightOfferModel]
    booking_requirements: AmadeusBookingRequirementsModel


class AmadeusFlightsPricingResponseModel(AmadeusBaseResponseModel):
    data: AmadeusFlightsPricingResponseDataModel


class AmadeusFlightConfirmResponseDataModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    type_: Annotated[Literal["flight-order"], Field(alias="type")]
    id_: IdField
    queuing_office_id: str
    associated_records: list[AmadeusAssociatedRecordModel]
    flight_offers: list[AmadeusFlightOfferModel]
    travelers: list[AmadeusTravelerModel]
    remarks: dict = {}
    ticketing_agreement: AmadeusTicketingAgreementsModel
    automated_process: list[AmadeusAutomatedProcessModel]
    contacts: list[AmadeusContactModel]


class AmadeusFlightConfirmResponseModel(AmadeusBaseResponseModel):
    data: AmadeusFlightConfirmResponseDataModel
