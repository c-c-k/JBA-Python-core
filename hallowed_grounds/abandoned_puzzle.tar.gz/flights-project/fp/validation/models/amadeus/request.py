from typing import Annotated
from typing import Literal

from pydantic import BaseModel
from pydantic import Field

from fp.validation.annotated_fields import IATACodeField
from fp.validation.annotated_fields import StrIsoDateField
from fp.validation.model_config import AMADEUS_RESPONSE_CONFIG
from .booking import AmadeusTravelerModel
from .booking import AmadeusTicketingAgreementsModel
from .booking import AmadeusContactModel
from .flight import AmadeusFlightOfferModel


class AmadeusBaseRequestGetModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    params: BaseModel
    data: BaseModel | None = None


class AmadeusBaseRequestPostModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    data: BaseModel


class AmadeusFlightsSearchRequestParamsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    origin_location_code: IATACodeField
    destination_location_code: IATACodeField
    departure_date: StrIsoDateField
    return_date: StrIsoDateField | None = None
    adults: int = 1


class AmadeusFlightsSearchRequestGetModel(AmadeusBaseRequestGetModel):
    params: AmadeusFlightsSearchRequestParamsModel


class AmadeusFlightsPricingRequestDataModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    type_: Annotated[Literal["flight-offers-pricing"],
                     Field(alias="type")] = "flight-offers-pricing"
    flight_offers: list[AmadeusFlightOfferModel]


class AmadeusFlightsPricingRequestPostModel(AmadeusBaseRequestPostModel):
    data: AmadeusFlightsPricingRequestDataModel


PLACEHOLDER_TRAVELERS = [AmadeusTravelerModel()]
PLACEHOLDER_TICKETING = AmadeusTicketingAgreementsModel()
PLACEHOLDER_CONTACTS = [AmadeusContactModel()]


class AmadeusFlightBookingRequestDataModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    type_: Annotated[Literal["flight-order"],
                     Field(alias="type")] = "flight-order"
    flight_offers: list[AmadeusFlightOfferModel]
    travelers: list[AmadeusTravelerModel] = PLACEHOLDER_TRAVELERS
    remarks: dict | None = None
    ticketing_agreement: AmadeusTicketingAgreementsModel = (
            PLACEHOLDER_TICKETING)
    contacts: list[AmadeusContactModel] = PLACEHOLDER_CONTACTS


class AmadeusFlightBookingRequestPostModel(AmadeusBaseRequestPostModel):
    data: AmadeusFlightBookingRequestDataModel
