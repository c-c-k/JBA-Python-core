from datetime import datetime

from pydantic import BaseModel

from fp.validation.annotated_fields import (
        AmadeusClassField, AmadeusTypeField, IATACodeField, IdField,
        MonetaryCostField, StrIsoDateField)
from fp.validation.model_config import AMADEUS_RESPONSE_CONFIG


class AmadeusTransitModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    iata_code: IATACodeField
    terminal: str | None = None
    at: datetime


class AmadeusSegmentModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    departure: AmadeusTransitModel
    arrival: AmadeusTransitModel
    carrier_code: str
    number: str
    aircraft: dict[str, str]
    operating: dict[str, str] | None = None
    duration: str
    id_: IdField
    number_of_stops: int
    co2_emissions: list[dict] | None = None
    blacklisted_in_e_u: bool | None = None


class AmadeusItineraryModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    duration: str | None = None
    segments: list[AmadeusSegmentModel]


class AmadeusFeeModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    amount: MonetaryCostField
    type_: AmadeusTypeField


class AmadeusTaxModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    amount: MonetaryCostField
    code: str


class AmadeusPriceModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    currency: str = "EUR"
    total: MonetaryCostField
    base: MonetaryCostField
    fees: list[AmadeusFeeModel] | None = None
    taxes: list[AmadeusTaxModel] | None = None
    refundable_taxes: MonetaryCostField | None = None
    grand_total: MonetaryCostField | None = None
    billing_currency: str | None = None


class AmadeusPricingOptionsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    fare_type: list[str]
    included_checked_bags_only: bool = True


class AmadeusSegmentFareDetailsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    segment_id: str
    cabin: str
    fare_basis: str
    branded_fare: str | None = None
    class_: AmadeusClassField
    slice_dice_indicator: str | None = None
    included_checked_bags: dict


class AmadeusTravelerPricingsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    traveler_id: str
    fare_option: str
    traveler_type: str
    price: AmadeusPriceModel
    fare_details_by_segment: list[AmadeusSegmentFareDetailsModel]


class AmadeusFlightOfferModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    type_: AmadeusTypeField = "flight-offer"
    id_: IdField
    source: str
    instant_ticketing_required: bool | None = None
    non_homogeneous: bool
    one_way: bool | None = None
    payment_card_required: bool | None = None
    last_ticketing_date: StrIsoDateField
    last_ticketing_date_time: StrIsoDateField | None = None
    number_of_bookable_seats: int | None = None
    itineraries: list[AmadeusItineraryModel]
    price: AmadeusPriceModel
    pricing_options: AmadeusPricingOptionsModel
    validating_airline_codes: list[str]
    traveler_pricings: list[AmadeusTravelerPricingsModel]


class AmadeusTravelerRequirementsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    traveler_id: str
    gender_required: bool = False
    document_required: bool = False
    date_of_birth_required: bool = False
    redress_required_if_any: bool = False
    residence_required: bool = False


class AmadeusBookingRequirementsModel(BaseModel):
    model_config = AMADEUS_RESPONSE_CONFIG

    email_address_required: bool = False
    mobile_phone_number_required: bool = False
    traveler_requirements: list[AmadeusTravelerRequirementsModel]
