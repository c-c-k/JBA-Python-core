# from decimal import Decimal
from typing import Annotated, Any

# from bson.objectid import ObjectId
from fastapi import Query
from pydantic import Field

from pydantic.functional_validators import AfterValidator

from .validators import normalize_char_code

AmadeusClassField = Annotated[str, Field(alias="class")]
AmadeusTypeField = Annotated[str, Field(alias="type")]
CountryCodeField = Annotated[
        str,
        AfterValidator(normalize_char_code),
        Field(
                pattern=r'^[A-Z]{2}$',
                description="Country 2 letter ISO 3166-1 alpha-2 code.")]
IATACodeField = Annotated[str,
                          AfterValidator(normalize_char_code),
                          Field(
                                  pattern=r'^[A-Z]{3}$',
                                  description="Airport 3 letter IATA code.")]
IATACodeQuery = Annotated[str,
                          Query(
                                  pattern=r'^[A-Z]{3}$',
                                  description="Airport 3 letter IATA code.")]
IdField = Annotated[str, Field(alias="id")]
# MongodbIdField = Annotated[str | None, Field(alias="_id")]
MongodbIdField = Annotated[Any, Field(alias="_id")]
# MonetaryCostField = Annotated[Decimal, Field(decimal_places=2)]
MonetaryCostField = str
NameMin2Field = Annotated[str, Field(min_length=2)]
StrIsoDateField = Annotated[
        str,
        Field(
                pattern=r'^\d{4}-\d{2}-\d{2}$',
                description="iso formatted date (e.g. 2000-01-01)")]
StrIsoDateQuery = Annotated[
        str,
        Query(
                pattern=r'^\d{4}-\d{2}-\d{2}$',
                description="iso formatted date (e.g. 2000-01-01)")]
