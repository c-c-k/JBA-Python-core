"""Validation related utilities.

"""

from pydantic import BaseModel, ValidationError


def gen_clean_data(data: list[dict], model: BaseModel) -> list[dict]:
    cleaned_data = []
    for entry in data:
        try:
            cleaned_entry = model(**entry).dict()
        except ValidationError:
            continue
        cleaned_data.append(cleaned_entry)
    return cleaned_data


def to_lower_camel(string: str) -> str:
    head, *tail = string.split("_")
    return head + ''.join(word.capitalize() for word in tail)
