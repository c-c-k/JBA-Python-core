from pydantic import ConfigDict

from fp.validation.utils import to_lower_camel

ALIAS_CAMEL_ALLOW_EXTRA = ConfigDict(
        extra="allow",
        populate_by_name=True,
        alias_generator=to_lower_camel,
)
ALIAS_CAMEL_IGNORE_EXTRA = ConfigDict(
        extra="ignore",
        populate_by_name=True,
        alias_generator=to_lower_camel,
)
AUTH_GENERAL_CONFIG = ALIAS_CAMEL_IGNORE_EXTRA
AMADEUS_RESPONSE_CONFIG = ALIAS_CAMEL_ALLOW_EXTRA
FLIGHTS_GENERAL_CONFIG = ALIAS_CAMEL_ALLOW_EXTRA
FLIGHTS_REQUEST_CONFIG = ConfigDict(
        extra="allow",
        populate_by_name=False,
        alias_generator=to_lower_camel,
)
MONGODB_DOCUMENT_MODEL_CONFIG = ALIAS_CAMEL_ALLOW_EXTRA
