"""
Business logic related to aiports.

"""

from pydantic import ValidationError

from fp.validation.models import AirportShortInfoModel, AirportBasicQueryModel


def find_airports(query: str) -> list[AirportShortInfoModel]:
    """Find and return a list of airports matching a query substring.

    The query is matched against an airport's IATA code, country code,
    country name, municipality and airport name.

    :query: The query substring to be searched for.
    :returns: A list of airports matching the query.
    """
    try:
        query = AirportBasicQueryModel(query=query)
    except ValidationError as err:
        # TODO: finish validation logic
        x = (query, err)
    raise Exception(str(x))
