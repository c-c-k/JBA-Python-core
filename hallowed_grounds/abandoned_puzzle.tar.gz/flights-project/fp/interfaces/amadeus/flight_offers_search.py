"""Wrapper for Amadeus: Flight Offers Search API
"""
import requests

from fp.core.config import config
from .auth import get_auth_header

_ROOT_URL = config["amadeus.root_url"]
_API_URL = _ROOT_URL + "/v2/shopping/flight-offers"


def amadeus_flight_offers_search(payload: dict,
                                 deserialize: bool = True) -> dict | str:
    if "params" in payload:
        params = payload["params"]
    else:
        params = payload
    response = requests.get(_API_URL, headers=get_auth_header(), params=params)
    return response.json() if deserialize else response.text
