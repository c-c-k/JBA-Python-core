"""Wrapper for Amadeus: Flight Offers Pricing API.
"""
import requests

from fp.core.config import config
from .auth import get_auth_header

_ROOT_URL = config["amadeus.root_url"]
_API_URL = _ROOT_URL + "/v1/shopping/flight-offers/pricing"


def amadeus_flight_offers_pricing(
        payload: dict | str, deserialize: bool = True) -> dict | str:
    headers = get_auth_header()
    if isinstance(payload, dict):
        response = requests.post(_API_URL, headers=headers, json=payload)
    else:
        headers["Content-Type"] = "application/json"
        response = requests.post(_API_URL, headers=headers, data=payload)
    return response.json() if deserialize else response.text
