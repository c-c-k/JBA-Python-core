import pymongo

from fp.core.config import config
from fp.core.logging import get_logger

logger = get_logger(__name__)

_client = None
_db = None


def get_client() -> pymongo.MongoClient:
    global _client
    if _client is None:
        _client = pymongo.MongoClient(
                **config["databases.mongodb.client_params"])
    return _client


def get_db() -> pymongo.database.Database:
    global _db
    if _db is None:
        _client = get_client()
        _db = _client[config["databases.mongodb.database"]]
    return _db
