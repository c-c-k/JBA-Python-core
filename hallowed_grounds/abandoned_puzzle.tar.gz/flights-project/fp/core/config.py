"""Project Dynaconf based configuration loading module

For details, see https://www.dynaconf.com/configuration
"""

from dynaconf import Dynaconf

config = Dynaconf(
    core_loaders=['YAML'],
    settings_files=['settings.yaml', 'logging_settings.yaml', '.secrets.yaml'],
    environments=True,
    envvar_prefix="FLIGTSPROJ",
    env_switcher='ENV_FOR_FLIGHTSPROJ',
    load_dotenv=True,
)
