from datetime import date, datetime, timedelta

from pydantic import ValidationError

from fp.core.logging import get_logger
from fp.interfaces.amadeus import amadeus_flight_offers_search
from fp.validation.models.amadeus import AmadeusFlightOfferModel
from fp.validation.models.amadeus import AmadeusFlightsSearchRequestGetModel
from fp.validation.models.amadeus import AmadeusFlightsSearchResponseModel
from fp.validation.models.flights import FlightsBaseInfoModel
from fp.validation.models.flights import FlightsDBFlightModel
from fp.validation.models.flights import FlightsListResponseModel
from fp.validation.models.flights import FlightsSearchGetModel

from ..dal import db_add_flights
from ..dal import db_get_flights

logger = get_logger(__name__)

# _FLIGHTS_SEARCH_REFRESH_INTERVAL = timedelta(days=1)
_FLIGHTS_SEARCH_REFRESH_INTERVAL = timedelta(days=60)


def date_to_datetime(d: date | None) -> datetime | None:
    return datetime.fromordinal(d.toordinal()) if d else None


def _result_requires_refresh(result: list[FlightsDBFlightModel]) -> bool:
    latest_update = max(
            (flight.amadeus_last_update_search_info for flight in result))
    return (
            datetime.utcnow()
            - latest_update) > _FLIGHTS_SEARCH_REFRESH_INTERVAL


def _amadeus_get_flights(
        request_model: FlightsSearchGetModel) -> list[AmadeusFlightOfferModel]:
    amadeus_request_model = AmadeusFlightsSearchRequestGetModel(
            params={
                    "origin_location_code": request_model.origin,
                    "destination_location_code": request_model.destination,
                    "departure_date": request_model.departure_date,
                    "return_date": request_model.return_date,
            })
    amadeus_request_data = amadeus_request_model.model_dump(
            by_alias=True, exclude_none=True)
    amadeus_response_json = amadeus_flight_offers_search(
            amadeus_request_data, deserialize=False)
    amadeus_response_model = (
            AmadeusFlightsSearchResponseModel.model_validate_json(
                    amadeus_response_json))
    return amadeus_response_model.data


def _import_flights_from_amadeus(request_model: FlightsSearchGetModel):
    amadeus_flights_list = _amadeus_get_flights(request_model)
    logger.debug(
            "Flight search results from Amadeus: \n%s"
            % str(amadeus_flights_list))
    db_add_flights(request_model, amadeus_flights_list)


def _proccess_flights_search(request_model: FlightsSearchGetModel):
    result = db_get_flights(request_model)
    logger.debug("result from db (pre refresh check): \n%s" % str(result))
    if (result == []) or _result_requires_refresh(result):
        _import_flights_from_amadeus(request_model)
        result = db_get_flights(request_model)
        logger.debug("result from db (post refresh check): \n%s" % str(result))
    response_model = FlightsListResponseModel(
            flight_offers=[
                    FlightsBaseInfoModel(
                            id_=str(flight.id_),
                            origin=request_model.origin,
                            destination=request_model.destination,
                            departure_date=request_model.departure_date,
                            return_date=request_model.return_date,
                            price=flight.amadeus_search_info.price.total,
                            currency=flight.amadeus_search_info.price.currency,
                    ) for flight in result
            ])
    logger.debug(
            "response_model generated from result: \n%s" % str(response_model))
    # response_json = response_model.model_dump_json(
    #         by_alias=True,
    #         # indent=4,
    #         exclude_none=True)
    # return response_json, len(response_model.flight_offers)
    return response_model, len(response_model.flight_offers)


def flights_search(**params):
    logger.info("Starting flights search for: %s" % str(params))
    try:
        request_model = FlightsSearchGetModel(**params)
    except ValidationError as err:
        logger.error(
                "Flight search params invalid:\n%s" % str(err), exc_info=False)
        response_json = None  # TODO ?= err.json()?
    except Exception as err:
        logger.exception(
                "Unhandled exception during flight search params validation:"
                "\n%s" % str(err), )
        response_json = None  # TODO: proper error response
    else:
        try:
            response_json, result_count = _proccess_flights_search(
                    request_model)
        except Exception as err:
            logger.exception(
                    "Unhandled exception during flight search execution:"
                    "\n%s" % str(err), )
            response_json = None  # TODO: proper error response
        else:
            logger.info(
                    "Found %d flight search results for: %s" %
                    (result_count, str(params)))
    return response_json
