from datetime import datetime, timedelta

from pydantic import ValidationError

from fp.core.logging import get_logger
from fp.interfaces.amadeus import amadeus_flight_offers_pricing
from fp.validation.models.amadeus import AmadeusFlightOfferModel
from fp.validation.models.amadeus import AmadeusFlightsPricingRequestPostModel
from fp.validation.models.amadeus import AmadeusFlightsPricingResponseModel
from fp.validation.models.flights import FlightDetailsModel
from fp.validation.models.flights import FlightsDBFlightModel
from fp.validation.models.flights import FlightsDetailsGetModel

from ..dal import db_get_flight_details
from ..dal import db_update_flight_details

logger = get_logger(__name__)

# _FLIGHT_DETAILS_REFRESH_INTERVAL = timedelta(hours=12)
_FLIGHT_DETAILS_REFRESH_INTERVAL = timedelta(days=50)


def _result_requires_refresh(result: list[FlightsDBFlightModel]) -> bool:
    latest_update = result.amadeus_last_update_booking_requirements
    return (
            datetime.utcnow()
            - latest_update) > _FLIGHT_DETAILS_REFRESH_INTERVAL


def _amadeus_get_flight_details(
        flight_info: AmadeusFlightOfferModel
) -> AmadeusFlightsPricingResponseModel:
    amadeus_request_model = AmadeusFlightsPricingRequestPostModel(
            data={"flight_offers": [flight_info]})
    amadeus_request_data = amadeus_request_model.model_dump_json(
            by_alias=True, exclude_none=True)
    logger.debug(
            "Raw flight details request to Amadeus: \n%s"
            % str(amadeus_request_data))
    amadeus_response_json = amadeus_flight_offers_pricing(
            amadeus_request_data, deserialize=False)
    logger.debug(
            "Raw flight details result from Amadeus: \n%s"
            % str(amadeus_response_json))
    amadeus_response_model = (
            AmadeusFlightsPricingResponseModel.model_validate_json(
                    amadeus_response_json))
    return amadeus_response_model.data


def _import_flight_details_from_amadeus(result: FlightsDBFlightModel):
    flight_info = result.amadeus_search_info
    amadeus_flight_details = _amadeus_get_flight_details(flight_info)
    logger.debug(
            "Validated flight details result from Amadeus: \n%s"
            % str(amadeus_flight_details))
    db_update_flight_details(result, amadeus_flight_details)


def _proccess_flight_details_acquisitions(
        request_model: FlightsDetailsGetModel):
    result = db_get_flight_details(request_model)
    # TODO: handle wrong flight request id
    logger.debug("result from db (pre refresh check): \n%s" % str(result))
    if ((result.amadeus_booking_requirements is None)
                or _result_requires_refresh(result)):
        _import_flight_details_from_amadeus(result)
        # TODO: handle amadeus pricing fare not found error json
        result = db_get_flight_details(request_model)
        logger.debug("result from db (post refresh check): \n%s" % str(result))
    response_model = FlightDetailsModel(
            id_=str(result.id_),
            origin=result.origin,
            destination=result.destination,
            departure_date=result.departure_date,
            return_date=result.return_date,
            price=result.amadeus_search_info.price.total,
            currency=result.amadeus_search_info.price.currency,
            booking_requirements=result.amadeus_booking_requirements)
    logger.debug(
            "response_model generated from result: \n%s" % str(response_model))
    # response_json = response_model.model_dump_json(
    #         by_alias=True,
    #         # indent=4,
    #         exclude_none=True)
    # return response_json, True  # TODO: invalidation due to missing details
    return response_model, True  # TODO: invalidation due to missing details


def flight_details(**params):
    logger.info("Starting flight details acquisition for: %s" % str(params))
    try:
        request_model = FlightsDetailsGetModel(**params)
    except ValidationError as err:
        logger.error(
                "Flight details params invalid:\n%s" % str(err),
                exc_info=False)
        response_json = None  # TODO ?= err.json()?
    except Exception as err:
        logger.exception(
                "Unhandled exception during flight details params validation:"
                "\n%s" % str(err), )
        response_json = None  # TODO: proper error response
    else:
        try:
            response_json, details_found = (
                    _proccess_flight_details_acquisitions(request_model))
        except Exception as err:
            logger.exception(
                    "Unhandled exception during flight details acquisition:"
                    "\n%s" % str(err), )
            response_json = None  # TODO: proper error response
        else:
            logger.info(
                    "Details found for: %s" if details_found else
                    "Details NOT found for: %s" % (str(params)))
    return response_json
