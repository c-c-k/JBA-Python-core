from bson.objectid import ObjectId

from fp.core.logging import get_logger
from fp.interfaces.amadeus import amadeus_flight_create_orders
from fp.validation.models.amadeus import AmadeusContactModel
from fp.validation.models.amadeus import AmadeusFlightBookingRequestDataModel
from fp.validation.models.amadeus import AmadeusFlightBookingRequestPostModel
from fp.validation.models.amadeus import AmadeusFlightConfirmResponseModel
from fp.validation.models.amadeus import AmadeusFlightOfferModel
from fp.validation.models.amadeus import AmadeusFlightsPricingResponseModel
from fp.validation.models.amadeus import AmadeusTravelerContactModel
from fp.validation.models.amadeus import AmadeusTravelerModel
from fp.validation.models.amadeus import AmadeusTravelerNameModel
from fp.validation.models.auth import AuthUserModel
from fp.validation.models.flights import FlightsBaseInfoModel
from fp.validation.models.flights import FlightsBookingInfoModel
from fp.validation.models.flights import FlightsBookingPostModel
from fp.validation.models.flights import FlightsBookingResponseModel
from fp.validation.models.flights import FlightsDBFlightModel
from fp.validation.models.flights import FlightsOrderInfoModel
from fp.validation.models.flights import FlightsUserInfoModel

from ..dal import db_add_booked_flight
from ..dal import db_get_booking_info
from ..dal import db_get_flight_info

logger = get_logger(__name__)


def construct_amadeus_request_model(
        flight_info: AmadeusFlightOfferModel,
        current_user: AuthUserModel,
) -> AmadeusFlightBookingRequestPostModel:
    flight_offers = [flight_info]
    travelers = [
            AmadeusTravelerModel(
                    name=AmadeusTravelerNameModel(
                            first_name=current_user.first_name,
                            last_name=current_user.last_name,
                    ),
                    contact=AmadeusTravelerContactModel(
                            email_address=current_user.email),
            )
    ]
    contacts = [
            AmadeusContactModel(
                    addressee_name=AmadeusTravelerNameModel(
                            first_name=current_user.first_name,
                            last_name=current_user.last_name,
                    ),
                    email_address=current_user.email)
    ]
    data = AmadeusFlightBookingRequestDataModel(
            flight_offers=flight_offers,
            travelers=travelers,
            contacts=contacts,
    )
    return AmadeusFlightBookingRequestPostModel(data=data)


def _amadeus_book_flight(
        flight_info: AmadeusFlightOfferModel,
        current_user: AuthUserModel,
) -> AmadeusFlightsPricingResponseModel:
    amadeus_request_model = construct_amadeus_request_model(
            flight_info,
            current_user,
    )
    amadeus_request_data = amadeus_request_model.model_dump_json(
            by_alias=True, exclude_none=True)
    amadeus_response_json = amadeus_flight_create_orders(
            amadeus_request_data, deserialize=False)
    logger.debug("Amadeus booking api response: \n%s" % amadeus_response_json)
    amadeus_response_model = (
            AmadeusFlightConfirmResponseModel.model_validate_json(
                    amadeus_response_json))
    return amadeus_response_model.data


def _book_flight_from_amadeus(
        flight_model: FlightsDBFlightModel,
        current_user: AuthUserModel,
) -> ObjectId:
    flight_info = flight_model.amadeus_search_info
    amadeus_booking_info = _amadeus_book_flight(flight_info, current_user)
    logger.debug(
            "Flight booking info from Amadeus: \n%s"
            % str(amadeus_booking_info))
    booked_flight_id = db_add_booked_flight(
            flight_model,
            amadeus_booking_info,
    )
    return booked_flight_id


def _proccess_flight_booking(
        request_model: FlightsBookingPostModel,
        current_user: AuthUserModel,
):
    flight_model = FlightsDBFlightModel.model_validate(
            db_get_flight_info(request_model))
    # TODO: handle wrong flight request id
    logger.debug("result from db (flight to book): \n%s" % str(flight_model))
    booked_flight_id = _book_flight_from_amadeus(flight_model, current_user)
    # TODO: handle amadeus pricing fare not found error json
    booked_flight = db_get_booking_info(booked_flight_id)
    logger.debug("result from db (booked flight): \n%s" % str(booked_flight))
    response_model = FlightsBookingResponseModel(
            data=FlightsBookingInfoModel(
                    id_=str(booked_flight_id),
                    flight_info=FlightsBaseInfoModel(
                            id_=str(flight_model.id_),
                            origin=flight_model.origin,
                            destination=flight_model.destination,
                            departure_date=flight_model.departure_date,
                            return_date=flight_model.return_date,
                            price=flight_model.amadeus_search_info.price.total,
                            currency=flight_model.amadeus_search_info.price
                            .currency,
                    ),
                    user_info=FlightsUserInfoModel(
                            first_name=booked_flight.amadeus_confirm_data
                            .travelers[0].name.first_name,
                            last_name=booked_flight.amadeus_confirm_data
                            .travelers[0].name.last_name,
                            email_address=booked_flight.amadeus_confirm_data
                            .travelers[0].contact.email_address,
                    ),
                    order_info=FlightsOrderInfoModel(
                            reference=booked_flight.amadeus_confirm_data
                            .associated_records[0].reference,
                            creation_date=booked_flight.amadeus_confirm_data
                            .associated_records[0].creation_date,
                            origin_system_code=booked_flight
                            .amadeus_confirm_data.associated_records[0]
                            .origin_system_code,
                    ),
            ))
    logger.debug(
            "response_model generated for booking: \n%s" % str(response_model))
    # response_json = response_model.model_dump_json(
    #         by_alias=True,
    #         # indent=4,
    #         exclude_none=True)
    # return response_json, True  # TODO: invalidation due to missing details
    return response_model, True  # TODO: invalidation due to missing details


def flight_book(
        request_model: FlightsBookingPostModel,
        current_user: AuthUserModel,
):
    logger.info(
            "Starting flight booking for flight: %s by user: %s" % (
                    str(request_model),
                    str(current_user),
            ))
    try:
        response_json, booking_success = (
                _proccess_flight_booking(request_model, current_user))
    except Exception as err:
        logger.exception(
                "Unhandled exception during flight booking:"
                "\n%s" % str(err), )
        response_json = None  # TODO: proper error response
    else:
        logger.info(
                "Flight booking success: %s" if booking_success else
                "Flight booking Failed: %s" % (str(request_model)))
    return response_json
