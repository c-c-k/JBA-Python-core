from .search import flights_search
from .detail import flight_details
from .book import flight_book
