from datetime import datetime

from bson.objectid import ObjectId

from fp.core.db.mongodb import get_db
from fp.core.logging import get_logger
from fp.validation.models.amadeus import AmadeusFlightsPricingResponseDataModel
from fp.validation.models.flights import FlightsDBFlightModel
from fp.validation.models.flights import FlightsDetailsGetModel

logger = get_logger(__name__)

_MONGODB_COLLECTION_FLIGHTS_NAME = "flights"


def db_get_flight_details(
        request_model: FlightsDetailsGetModel) -> FlightsDBFlightModel:
    db = get_db()
    collection = db[_MONGODB_COLLECTION_FLIGHTS_NAME]
    document = collection.find_one({
            '_id': ObjectId(request_model.id_),
    })
    result = FlightsDBFlightModel.model_validate(document)
    return result


def db_update_flight_details(
        result: FlightsDBFlightModel,
        amadeus_flight_details: AmadeusFlightsPricingResponseDataModel):
    db = get_db()
    collection = db[_MONGODB_COLLECTION_FLIGHTS_NAME]
    collection.update_one(
            {
                    '_id': result.id_,
            }, {
                    '$set': {
                            'amadeusSearchInfo':
                            amadeus_flight_details.flight_offers[0].model_dump(
                            ),
                            'amadeusBookingRequirements':
                            amadeus_flight_details.booking_requirements
                            .model_dump(),
                            'amadeusLastUpdateBookingRequirements':
                            datetime.utcnow()
                    }
            })
