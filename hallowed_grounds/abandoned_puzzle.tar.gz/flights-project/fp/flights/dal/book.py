from bson.objectid import ObjectId

from fp.core.logging import get_logger
from fp.validation.models.amadeus import AmadeusFlightConfirmResponseDataModel
from fp.validation.models.flights import FlightsBookingPostModel
from fp.validation.models.flights import FlightsDBBookingModel
from fp.validation.models.flights import FlightsDBFlightModel

from fp.core.db.mongodb import get_db

logger = get_logger(__name__)

_MONGODB_COLLECTION_FLIGHTS_NAME = "flights"
_MONGODB_COLLECTION_BOOKINGS_NAME = "bookings"


def db_get_booking_info(booked_flight_id: ObjectId) -> FlightsDBBookingModel:
    db = get_db()
    collection = db[_MONGODB_COLLECTION_BOOKINGS_NAME]
    document = collection.find_one({
            '_id': booked_flight_id,
    })
    result = FlightsDBBookingModel.model_validate(document)
    return result


def db_get_flight_info(
        request_model: FlightsBookingPostModel) -> FlightsDBFlightModel:
    db = get_db()
    collection = db[_MONGODB_COLLECTION_FLIGHTS_NAME]
    document = collection.find_one({
            '_id': ObjectId(request_model.id_),
    })
    result = FlightsDBFlightModel.model_validate(document)
    return result


def db_add_booked_flight(
        flight_model: FlightsDBFlightModel,
        amadeus_booking_info: AmadeusFlightConfirmResponseDataModel):
    db = get_db()
    collection = db[_MONGODB_COLLECTION_BOOKINGS_NAME]
    booking_model = FlightsDBBookingModel(
            flight_id=flight_model.id_,
            amadeus_confirm_data=amadeus_booking_info,
    )
    booked_flight_id = collection.insert_one(
            booking_model.model_dump()).inserted_id
    return booked_flight_id
