from datetime import datetime

from pymongo import InsertOne, UpdateMany

from fp.core.db.mongodb import get_db
from fp.core.logging import get_logger
from fp.validation.models.amadeus import AmadeusFlightOfferModel
from fp.validation.models.flights import FlightsDBFlightModel
from fp.validation.models.flights import FlightsSearchGetModel

logger = get_logger(__name__)

_MONGODB_COLLECTION_FLIGHTS_NAME = "flights"


def db_get_flights(
        request_model: FlightsSearchGetModel) -> list[FlightsDBFlightModel]:
    db = get_db()
    collection = db[_MONGODB_COLLECTION_FLIGHTS_NAME]
    documents = collection.find(
            {
                    'isCurrent': True,
                    'isValid': True,
                    'origin': request_model.origin,
                    'destination': request_model.destination,
                    'departureDate': request_model.departure_date,
                    'returnDate': request_model.return_date,
            })
    result = [
            FlightsDBFlightModel.model_validate(document)
            for document in documents
    ]
    return result


def _db_request_add_new_flight(
        request_model: FlightsSearchGetModel,
        amadeus_flight: AmadeusFlightOfferModel,
        utcnow: datetime) -> InsertOne:
    flight_model = FlightsDBFlightModel(
            origin=request_model.origin,
            destination=request_model.destination,
            departure_date=request_model.departure_date,
            return_date=request_model.return_date,
            amadeus_search_info=amadeus_flight,
            amadeus_last_update_search_info=utcnow,
    )
    flight_json = flight_model.model_dump(by_alias=True, exclude_none=True)
    return InsertOne(flight_json)


def db_add_flights(
        request_model: FlightsSearchGetModel,
        amadeus_flights_list: [AmadeusFlightOfferModel]):
    db = get_db()
    collection = db[_MONGODB_COLLECTION_FLIGHTS_NAME]
    db_request_invalidat_old_flights = UpdateMany(
            {
                    'isCurrent': True,
                    'origin': request_model.origin,
                    'destination': request_model.destination,
                    'departDate': request_model.departure_date,
                    'returnDate': request_model.return_date,
            }, {'$set': {
                    'isCurrent': False
            }})
    utcnow = datetime.utcnow()
    db_request_add_new_flights = (
            _db_request_add_new_flight(request_model, amadeus_flight, utcnow)
            for amadeus_flight in amadeus_flights_list)
    db_requests = [
            db_request_invalidat_old_flights, *db_request_add_new_flights
    ]
    logger.debug(
            "Database update&add bulk operations list: \n%s"
            % str(db_requests))
    collection.bulk_write(db_requests)
