from jose import JWTError, jwt
from passlib.context import CryptContext

from fp.core.config import config

SECRET_KEY = config["fastapi.secret_key"]
ALGORITHM = "HS256"

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class TokenDecodeError(Exception):
    pass


def auth_verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def auth_get_password_hash(password):
    return pwd_context.hash(password)


def encode_token(to_encode: dict) -> str:
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(encoded_token: str) -> dict:
    try:
        return jwt.decode(encoded_token, SECRET_KEY, algorithms=ALGORITHM)
    except JWTError:
        raise TokenDecodeError
