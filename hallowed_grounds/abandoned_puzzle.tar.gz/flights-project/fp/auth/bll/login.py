from datetime import datetime, timedelta

from fastapi import HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm

from fp.core.config import config
from fp.core.logging import get_logger
from fp.validation.models.auth import (
        AuthTokenModel, )
from ..dal import auth_db_get_user
from ..utils import auth_verify_password, encode_token

logger = get_logger(__name__)

ACCESS_TOKEN_EXPIRE_MINUTES = config["fastapi.access_token_expire_minutes"]


def auth_authenticate_user(username: str, password: str):
    user = auth_db_get_user(username)
    if not user:
        return False
    if not auth_verify_password(password, user.hashed_password):
        return False
    return user


def auth_create_access_token(
        data: dict,
        expires_delta: timedelta | None = None,
):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_token = encode_token(to_encode)
    return encoded_token


def auth_login_for_access_token(form_data: OAuth2PasswordRequestForm):
    user = auth_authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth_create_access_token(
            data={"sub": user.username}, expires_delta=access_token_expires)
    return AuthTokenModel(access_token=access_token, token_type="bearer")
