from fastapi import HTTPException, status

from fp.core.config import config
from fp.core.logging import get_logger
from fp.validation.models.auth import AuthUserInDBModel
from fp.validation.models.auth import AuthUserRegistrationModel

from ..dal import auth_db_add_user
from ..dal import auth_db_get_user
from ..utils import auth_get_password_hash

logger = get_logger(__name__)

ACCESS_TOKEN_EXPIRE_MINUTES = config["fastapi.access_token_expire_minutes"]


def auth_register_user(registration_data: AuthUserRegistrationModel):
    if auth_db_get_user(registration_data.username) is not None:
        raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Username already exists",
        )
    hashed_password = auth_get_password_hash(registration_data.password1)
    user_model = AuthUserInDBModel(
            username=registration_data.username,
            email=registration_data.email,
            first_name=registration_data.first_name,
            last_name=registration_data.last_name,
            hashed_password=hashed_password,
    )
    success = auth_db_add_user(user_model)
    return {"success": success}
