from fp.core.db.mongodb import get_db
from fp.validation.models.auth import AuthUserInDBModel

from ..utils import auth_get_password_hash

_MONGODB_COLLECTION_USERS_NAME = "users"
fake_users_db = {
        "testuser": {
                "username": "testuser",
                "full_name": "Test User",
                "email": "testuser@example.com",
                "hashed_password": auth_get_password_hash("secret"),
                "disabled": False,
        }
}


def auth_db_add_user(user_model: AuthUserInDBModel):
    db = get_db()
    collection = db[_MONGODB_COLLECTION_USERS_NAME]
    result = collection.insert_one(user_model.model_dump())
    return result.acknowledged


def auth_db_get_user(username: str):
    db = get_db()
    collection = db[_MONGODB_COLLECTION_USERS_NAME]
    document = collection.find_one({'username': username})
    if document is not None:
        return AuthUserInDBModel.model_validate(document)


def auth_fake_db_get_user(username: str):
    db = fake_users_db
    if username in db:
        user_dict = db[username]
        return AuthUserInDBModel(**user_dict)
