"""FastAPI API flights related logic
"""

from typing import Annotated

from fastapi import APIRouter
from fastapi import Depends

from fp.auth.bll import auth_get_current_active_user
from fp.flights.bll import flight_book
from fp.flights.bll import flight_details
from fp.flights.bll import flights_search
from fp.validation.annotated_fields import IATACodeQuery
from fp.validation.annotated_fields import StrIsoDateQuery
from fp.validation.models.auth import AuthUserModel
from fp.validation.models.flights import FlightDetailsModel
from fp.validation.models.flights import FlightsBookingPostModel
from fp.validation.models.flights import FlightsBookingResponseModel
from fp.validation.models.flights import FlightsListResponseModel

router = APIRouter()


@router.get("/search", response_model=FlightsListResponseModel)
def api_flight_search(
        origin: IATACodeQuery,
        destination: IATACodeQuery,
        departure_date: StrIsoDateQuery,
        return_date: StrIsoDateQuery | None = None,
):
    params = {
            "origin": origin,
            "destination": destination,
            "departure_date": departure_date,
            "return_date": return_date,
    }
    return flights_search(**params)


@router.get("/detail/{flight_id}", response_model=FlightDetailsModel)
def api_flight_details(flight_id: str):
    return flight_details(id_=flight_id)


@router.post("/book", response_model=FlightsBookingResponseModel)
def api_flight_book(
        request_model: FlightsBookingPostModel,
        current_user: Annotated[AuthUserModel,
                                Depends(auth_get_current_active_user)],
):
    return flight_book(request_model, current_user)
