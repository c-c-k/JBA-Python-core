"""FastAPI API authentication/autherization related logic
"""

from typing import Annotated

from fastapi import APIRouter
from fastapi import Depends
# from fastapi import Response
from fastapi.security import OAuth2PasswordRequestForm

from fp.auth.bll import auth_login_for_access_token
from fp.auth.bll import auth_get_current_active_user
from fp.auth.bll import auth_register_user
from fp.core.logging import get_logger
from fp.validation.models.auth import AuthTokenModel
from fp.validation.models.auth import AuthUserModel
from fp.validation.models.auth import AuthUserRegistrationModel

logger = get_logger(__name__)

router = APIRouter()


@router.post("/register")
# def api_register_user(registration_data: AuthUserRegistrationModel, response: Response):
def api_register_user(registration_data: AuthUserRegistrationModel):
    # logger.debug("----!!! response !!! : " + str(response.__dict__))
    # return response
    return auth_register_user(registration_data)


@router.post("/token", response_model=AuthTokenModel)
def api_login_for_access_token(
        form_data: Annotated[OAuth2PasswordRequestForm,
                             Depends()]):
    return auth_login_for_access_token(form_data)


@router.get("/users/me/", response_model=AuthUserModel)
def read_users_me(
        current_user: Annotated[AuthUserModel,
                                Depends(auth_get_current_active_user)]):
    return current_user
