"""FastAPI API logic
"""

from fastapi import FastAPI
from fastapi.routing import APIRoute
from fastapi.middleware.cors import CORSMiddleware

from fp.core.config import config
from fp.core.logging import get_logger
from fp.validation.utils import to_lower_camel
from . import auth
from . import flights

logger = get_logger(__name__)

app = FastAPI()

app.add_middleware(
        CORSMiddleware,
        allow_origins=config["fastapi.cors_allowed_origins"],
        # allow_origins=[],
        # allow_origins="*",
        # NOTE: allow_origins_regex seems to block no-cors requests as well
        # allow_origins_regex=r"http://fp.*",
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        # expose_headers=[]
)

app.include_router(auth.router, prefix="/api/auth")
app.include_router(flights.router, prefix="/api/flights")


@app.get("/")
@app.get("/api")
def api_root():
    return {
            "message":
            "Welcome to Flights Project API, "
            "please use one of the available API urls "
            "to search and book flights"
    }


for route in app.routes:
    if isinstance(route, APIRoute):
        for param in route.dependant.query_params:
            if ("_" in param.name) and (not param.field_info.alias or
                                        (param.name
                                         == param.field_info.alias)):
                param.field_info.alias = to_lower_camel(param.name)
