import datetime as dt
# from pprint import pprint

import requests

from fp.validation.models.flights import FlightsListResponseModel
from scratchpad.utils import output_wrapper

# JSON_HEADER = {"Content-Type": "application/json", "charset": "utf-8"}
HOST = "http://localhost:8123"
# HOST = "http://83-229-73-53.cloud-xip.com:8123"
ROOT = HOST + "/"
API_ROOT = HOST + "/api"
AUTH_ROOT = HOST + "/api/auth"
FLIGHTS_ROOT = HOST + "/api/flights"

DEMO_USER = {
        "username": "demouser",
        "firstName": "Demo",
        "lastName": "User",
        "email": "demouser@example.com",
        "password1": "secret",
        "password2": "secret",
}


@output_wrapper
def spad_get_root():
    resp = requests.get(ROOT)
    return resp.json()


@output_wrapper
def spad_get_api_root():
    resp = requests.get(ROOT)
    return resp.json()


@output_wrapper
def spad_check_cors():
    url = API_ROOT
    headers = {"Origin": "http://localhost"}
    resp = requests.get(url, headers=headers)
    print("----- request: ", resp.request.__dict__)
    return resp


@output_wrapper
def spad_register_demo_user():
    url = AUTH_ROOT + "/register"
    payload = DEMO_USER
    headers = {"Origin": "http://yar.com:8123"}
    resp = requests.post(url, headers=headers, json=payload)
    print(resp.request.__dict__)
    return resp


@output_wrapper
def spad_login_demo_user():
    spad_register_demo_user()
    url = AUTH_ROOT + "/token"
    headers = {"application": "x-www-form-urlencoded"}
    payload = {
            "username": DEMO_USER["username"],
            "password": DEMO_USER["password1"],
    }
    resp = requests.post(url, headers=headers, data=payload)
    return resp


@output_wrapper
def spad_get_demo_auth_api():
    login_resp = spad_login_demo_user().json()
    token = login_resp["accessToken"]
    url = AUTH_ROOT + "/users/me"
    headers = {"Authorization": "Bearer " + token}
    resp = requests.get(url, headers=headers)
    return resp


@output_wrapper
def spad_get_flight_search(two_way=False):
    depart_date = dt.date.today() + dt.timedelta(days=9)
    depart_date = depart_date.strftime("%Y-%m-%d")
    if two_way:
        return_date = dt.date.today() + dt.timedelta(days=14)
        return_date = return_date.strftime("%Y-%m-%d")
    else:
        return_date = None
    payload = {
            "origin": "TLV",
            "destination": "LAS",
            "departureDate": depart_date,
            "returnDate": return_date,
    }
    url = FLIGHTS_ROOT + "/search"
    resp = requests.get(url, params=payload)
    return resp


@output_wrapper
def spad_get_flight_detail(*, two_way=False, flight_id: str | None = None):
    if not flight_id:
        flights_resp = spad_get_flight_search(two_way=two_way)
        flights_json = flights_resp.text
        flights_model = (
                FlightsListResponseModel.model_validate_json(flights_json))
        flight_id = flights_model.flight_offers[0].id_
        print('test flight id: ', flight_id)
    url = FLIGHTS_ROOT + f"/detail/{flight_id}"
    resp = requests.get(url)
    return resp


@output_wrapper
def spad_post_flight_booking(two_way=False):
    flights_resp = spad_get_flight_search(two_way=two_way)
    flights_json = flights_resp.text
    flights_model = FlightsListResponseModel.model_validate_json(flights_json)
    flight_id = flights_model.flight_offers[0].id_
    print('test flight id: ', flight_id)
    spad_get_flight_detail(flight_id=flight_id)
    login_resp = spad_login_demo_user()
    login_json = login_resp.json()
    token = login_json["accessToken"]
    headers = {"Authorization": "Bearer " + token}
    print(headers)
    url = FLIGHTS_ROOT + "/book"
    payload = {"id": flight_id}
    resp = requests.post(url, headers=headers, json=payload)
    return resp


def main():
    # spad_get_root()
    # spad_get_api_root()
    # spad_check_cors()
    # spad_get_demo_auth_api()
    # spad_output_register_resp()
    # spad_output_login_resp()
    # spad_get_flight_search()
    # spad_get_flight_detail()
    # spad_post_flight_booking()
    pass
