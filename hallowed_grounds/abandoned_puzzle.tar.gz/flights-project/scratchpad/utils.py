import datetime as dt
import json
from pathlib import Path
from pprint import pprint
from typing import Callable

DUMP_ROOT = Path(__file__).parent.resolve().joinpath("data_dumps")


def dump_json_data(
        data: dict,
        base_name: str,
        serialize: bool = True,
        add_extension: bool = True,
        print_before: bool = False,
        print_after: bool = False,
        add_timestamp: bool = False,
):
    if print_before:
        pprint(data)
    if add_timestamp:
        base_name += dt.datetime.now().strftime("_%Y%m%dT%H%M%S")
    if add_extension:
        base_name = str(base_name) + ".json"
    file_path = DUMP_ROOT.joinpath(base_name)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="UTF-8") as f:
        if serialize:
            json.dump(data, f, indent=4)
        else:
            f.write(data)
    if print_after:
        with open(file_path, "r", encoding="UTF-8") as f:
            pprint(json.load(f))


def load_json_data(fname: str, deserialize: bool = True):
    file_path = DUMP_ROOT.joinpath("".join((fname, ".json")))
    with open(file_path, "r", encoding="UTF-8") as f:
        data = json.load(f) if deserialize else f.read()
    return data


def output_wrapper(func: Callable):

    def wrapper(*args, **kwargs):
        # if kwargs.pop("no_wrap", False):
        #     return func(*args, **kwargs)
        print("=" * 44)
        print(f"==== output from {func.__name__} ====")
        return_value = func(*args, **kwargs)
        print("----- return value -----")
        try:
            pprint(return_value.__dict__)
        except AttributeError:
            pprint(return_value)
        print("----- return type: ", type(return_value))
        print("-" * 40)
        return return_value

    return wrapper
