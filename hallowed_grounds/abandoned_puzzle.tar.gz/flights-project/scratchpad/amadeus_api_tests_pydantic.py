"""Ad hoc tests for checking the Amadeus requests handling by pydantic

The tests are meant to check that the pydantic models generate correct
requests for the Amadeus API, the checks for proper handling of responses
should go into ./amadeus_reserialization_tests.py .
Also, tests for checking the basic Amadeus API functionality itself should go
into ./amadeus_api_tests.py .
Due to the complexity and irregularity of the data returned by the Amadeus API,
These tests rely on manually checking the dumped files.
"""
import datetime as dt
from pathlib import Path

from fp.validation.models.amadeus.request import (
        AmadeusFlightsSearchRequestGetModel,
        AmadeusFlightsPricingRequestPostModel,
        AmadeusFlightBookingRequestPostModel)
from fp.validation.models.amadeus.response import (
        AmadeusFlightsSearchResponseModel,
        AmadeusFlightsPricingResponseModel,
)
from fp.interfaces.amadeus import flight_offers_search
from fp.interfaces.amadeus import amadeus_flight_offers_pricing
from fp.interfaces.amadeus import amadeus_flight_create_orders

from .utils import dump_json_data, load_json_data


def spad_flights_offers_search(two_way=False):
    depart_date = dt.date.today() + dt.timedelta(days=7)
    if two_way:
        return_date = depart_date + dt.timedelta(days=14)
    else:
        return_date = None
    request_model = AmadeusFlightsSearchRequestGetModel(
            params={
                    "origin_location_code": "TLV",
                    "destination_location_code": "LAS",
                    "departure_date": depart_date,
                    "return_date": return_date,
            })
    request_data = request_model.model_dump(by_alias=True, exclude_none=True)
    # response_data = str(request_data)
    response_data = flight_offers_search.amadeus_flight_offers_search(
            request_data, deserialize=False)
    if two_way:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath("flights_search_two_way"),
                serialize=False)
    else:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath("flights_search_one_way"),
                serialize=False)


def spad_flight_offers_pricing(two_way=False):
    if two_way:
        data_file = Path("api_via_pydantic").joinpath("flights_search_two_way")
    else:
        data_file = Path("api_via_pydantic").joinpath("flights_search_one_way")
    data_from_offers = load_json_data(data_file.as_posix(), deserialize=False)
    data_from_offers = AmadeusFlightsSearchResponseModel.model_validate_json(
            data_from_offers)
    single_offer = data_from_offers.data[0]
    request_model = AmadeusFlightsPricingRequestPostModel(
            data={"flight_offers": [single_offer]})
    request_payload = request_model.model_dump_json(
            by_alias=True,
            # indent=4,
            exclude_none=True)
    # response_data = str(request_payload)
    # root_url = flight_offers_pricing._ROOT_URL
    # orig_api_url = flight_offers_pricing._API_URL
    # flight_offers_pricing._API_URL = orig_api_url.replace(
    #         root_url, "http://localhost:12121")
    response_data = amadeus_flight_offers_pricing.flight_offers_pricing(
            request_payload, serialize=False)
    # flight_offers_pricing._API_URL = orig_api_url
    if two_way:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath("flight_pricing_two_way"),
                serialize=False)
    else:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath("flight_pricing_one_way"),
                serialize=False)


def spad_flight_create_orders(two_way=False, switch_id=False):
    if two_way:
        data_file = Path("api_via_pydantic").joinpath("flight_pricing_two_way")
    else:
        data_file = Path("api_via_pydantic").joinpath("flight_pricing_one_way")
    data_from_offers = load_json_data(data_file.as_posix(), deserialize=False)
    data_from_offers = AmadeusFlightsPricingResponseModel.model_validate_json(
            data_from_offers)
    single_offer = data_from_offers.data.flight_offers[0]
    if switch_id:
        single_offer.id_ = "aBc3204$sdf"
    request_model = AmadeusFlightBookingRequestPostModel(
            data={"flight_offers": [single_offer]})
    request_payload = request_model.model_dump_json(
            by_alias=True,
            # indent=4,
            exclude_none=True)
    # response_data = request_payload
    # root_url = flight_create_orders._ROOT_URL
    # orig_api_url = flight_create_orders._API_URL
    # flight_create_orders._API_URL = orig_api_url.replace(
    #         root_url, "http://localhost:12121")
    response_data = amadeus_flight_create_orders.flight_create_orders(
            request_payload, serialize=False)
    # flight_create_orders._API_URL = orig_api_url
    if switch_id:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath(
                        "flight_booking_confirm_switch_id"),
                serialize=False)
    elif two_way:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath(
                        "flight_booking_confirm_two_way"),
                serialize=False)
    else:
        dump_json_data(
                response_data,
                Path("api_via_pydantic").joinpath(
                        "flight_booking_confirm_one_way"),
                serialize=False)


def main():
    # spad_flights_offers_search(two_way=False)
    spad_flight_offers_pricing(two_way=False)
    spad_flight_create_orders(two_way=False)
    # spad_flight_create_orders(switch_id=True)
    # spad_flights_offers_search(two_way=True)
    # spad_flight_offers_pricing(two_way=True)
    # spad_flight_create_orders(two_way=True)
    pass
