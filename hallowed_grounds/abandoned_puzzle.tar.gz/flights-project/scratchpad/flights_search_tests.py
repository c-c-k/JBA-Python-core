"""Ad hoc tests for checking the fp.flights package
"""
import datetime as dt

from fp.validation.models.flights import (
        FlightsListResponseModel, FlightsBookingPostModel)
from fp.flights.bll.search import flights_search
from fp.flights.bll.detail import flight_details
from fp.flights.bll.book import flight_book

from .utils import output_wrapper


@output_wrapper
def spad_bad_flight_params():
    return flights_search(origin=1)


@output_wrapper
def spad_normal_flight_params_one_way():
    depart_date = dt.date.today() + dt.timedelta(days=7)
    depart_date = depart_date.strftime("%Y-%m-%d")
    params = {
            "origin": "TLV",
            "destination": "LAS",
            "departure_date": depart_date,
    }
    return flights_search(**params)


@output_wrapper
def spad_normal_flight_params_two_way():
    depart_date = dt.date.today() + dt.timedelta(days=7)
    depart_date = depart_date.strftime("%Y-%m-%d")
    return_date = dt.date.today() + dt.timedelta(days=14)
    return_date = return_date.strftime("%Y-%m-%d")
    params = {
            "origin": "TLV",
            "destination": "LAS",
            "departure_date": depart_date,
            "return_date": return_date,
    }
    return flights_search(**params)[:200]


@output_wrapper
def spad_flight_details():
    depart_date = dt.date.today() + dt.timedelta(days=7)
    depart_date = depart_date.strftime("%Y-%m-%d")
    return_date = dt.date.today() + dt.timedelta(days=14)
    return_date = return_date.strftime("%Y-%m-%d")
    params = {
            "origin": "TLV",
            "destination": "LAS",
            "departure_date": depart_date,
            "return_date": return_date,
    }
    result_json = flights_search(**params)
    result_model = FlightsListResponseModel.model_validate_json(result_json)
    flight_id = result_model.flight_offers[0].id_
    print('test flight id: ', flight_id)
    return flight_details(id_=flight_id)


@output_wrapper
def spad_flight_booking():
    depart_date = dt.date.today() + dt.timedelta(days=7)
    depart_date = depart_date.strftime("%Y-%m-%d")
    return_date = dt.date.today() + dt.timedelta(days=14)
    return_date = return_date.strftime("%Y-%m-%d")
    params = {
            "origin": "TLV",
            "destination": "LAS",
            "departure_date": depart_date,
            "return_date": return_date,
    }
    result_json = flights_search(**params)
    result_model = FlightsListResponseModel.model_validate_json(result_json)
    flight_id = result_model.flight_offers[0].id_
    print('test flight id: ', flight_id)
    request_model = FlightsBookingPostModel(id_=flight_id)
    return flight_book(request_model)


def main():
    # spad_bad_flight_params()
    # spad_normal_flight_params_one_way()
    # spad_normal_flight_params_two_way()
    # spad_flight_details()
    # spad_flight_booking()
    pass
