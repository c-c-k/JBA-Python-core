import importlib

# from scratchpad import amadeus_api_tests as current
# from scratchpad import amadeus_reserialization_tests as current
# from scratchpad import amadeus_api_tests_pydantic as current
# from scratchpad import flights_search_tests as current
from scratchpad import fastapi_tests as current


def run():
    importlib.reload(current)
    current.main()
