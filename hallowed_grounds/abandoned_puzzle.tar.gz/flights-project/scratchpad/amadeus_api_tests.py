"""Ad hoc tests for interacting with the Amadeus API

Due to the complexity and irregularity of the data returned by the Amadeus API,
These tests rely on manually checking the dumped files.
"""

from collections import defaultdict
import datetime as dt
import importlib
import time

from fp.core.config import config
from fp.interfaces.amadeus import auth
from fp.interfaces.amadeus import amadeus_flight_offers_search
from fp.interfaces.amadeus import amadeus_flight_offers_pricing
from fp.interfaces.amadeus import amadeus_flight_create_orders

from .utils import dump_json_data, load_json_data

MAX_FLIGHT_PRICING_ITEMS = 6


def spad_get_auth_data_full():
    importlib.reload(auth)
    time.sleep(1)
    data = auth._get_amadeus_auth_token()
    data["access_token"] = "[a-zA-Z0-9]{28}"
    data["application_name"] = "AppName"
    data["client_id"] = "[a-zA-Z0-9]{32}"
    data["username"] = "user@email.com"
    dump_json_data(data, "auth_token", print_after=True)


def spad_get_auth_header():
    importlib.reload(auth)
    time.sleep(1)
    # config["amadeus.next_refresh"] = None
    token = auth.get_auth_header()
    print("token from get_token: ", token)
    print("expires: ", time.ctime(config["amadeus.next_refresh"]))
    print("now:     ", time.ctime(time.time()))


def spad_flights_offers_search(two_way=False):
    # importlib.reload(flight_offers_search)
    depart_date = dt.date.today() + dt.timedelta(days=7)
    request_payload = {
            "originLocationCode": "LON",
            "destinationLocationCode": "PAR",
            "departureDate": depart_date.strftime("%Y-%m-%d"),
            "adults": 1,
    }
    if two_way:
        return_date = depart_date + dt.timedelta(days=14)
        request_payload["returnDate"] = return_date.strftime("%Y-%m-%d")
    response_data = amadeus_flight_offers_search(request_payload)
    if two_way:
        dump_json_data(response_data, "flights_search_two_way")
    else:
        dump_json_data(response_data, "flights_search_one_way")


def get_max_flights_by_airline(data: dict) -> dict:
    flights_by_airline = defaultdict(list)
    for flight in data:
        airline = flight["validatingAirlineCodes"][0]
        flights_by_airline[airline].append(flight)
    max_flights_count = 0
    max_flights_list = []
    for flights in flights_by_airline.values():
        if len(flights) > max_flights_count:
            max_flights_count = len(flights)
            max_flights_list = flights
    return max_flights_list[:MAX_FLIGHT_PRICING_ITEMS]


def spad_flight_offers_pricing(two_way=False):
    # importlib.reload(amadeus_flight_offers_pricing)
    if two_way:
        data_from_offers = load_json_data("flights_search_two_way")
    else:
        data_from_offers = load_json_data("flights_search_one_way")
        # data_from_offers = load_json_data("temp-flights_search_one_way")
    data_from_offers = get_max_flights_by_airline(data_from_offers["data"])
    # data_from_offers = [data_from_offers["data"][0]]
    request_payload = {
            "data": {
                    "type": "flight-offers-pricing",
                    "flightOffers": data_from_offers
            }
    }
    # response_data = request_payload
    # root_url = flight_offers_pricing._ROOT_URL
    # orig_api_url = flight_offers_pricing._API_URL
    # flight_offers_pricing._API_URL = orig_api_url.replace(
    #         root_url, "http://localhost:12121")
    response_data = amadeus_flight_offers_pricing(request_payload)
    # flight_offers_pricing._API_URL = orig_api_url
    if two_way:
        dump_json_data(response_data, "flight_pricing_two_way")
    else:
        dump_json_data(response_data, "flight_pricing_one_way")
        # dump_json_data(response_data, "temp-flight_pricing_one_way")


def spad_flight_create_orders(two_way=False, switch_id=False):
    # importlib.reload(amadeus_flight_create_orders)
    if two_way:
        data_file = "flight_pricing_two_way"
    else:
        data_file = "flight_pricing_one_way"
    data_from_offers = load_json_data(data_file)
    data_from_offers = data_from_offers["data"]["flightOffers"]
    single_offer = data_from_offers[0]
    if switch_id:
        single_offer["id"] = "aBc3204$sdf"
    request_payload = load_json_data("flight_booking_request_example")
    request_payload["data"]["flightOffers"] = [single_offer]
    response_data = amadeus_flight_create_orders(request_payload)
    if switch_id:
        dump_json_data(response_data, "flight_booking_confirm_switch_id")
    elif two_way:
        dump_json_data(response_data, "flight_booking_confirm_two_way")
    else:
        dump_json_data(response_data, "flight_booking_confirm_one_way")


def main():
    # spad_get_auth_data_full()
    # spad_get_auth_header()
    # spad_flights_offers_search(two_way=False)
    # spad_flight_offers_pricing(two_way=False)
    # spad_flight_create_orders(two_way=False)
    # spad_flights_offers_search(two_way=True)
    # spad_flight_offers_pricing(two_way=True)
    # spad_flight_create_orders(two_way=True)
    # spad_flight_create_orders(switch_id=True)
    pass
