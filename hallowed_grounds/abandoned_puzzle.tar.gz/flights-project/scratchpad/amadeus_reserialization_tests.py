"""Ad hoc tests for checking the Amadeus response handling by pydantic

The tests rely on the JSON dump files created by ./amadeus_api_tests.py and
are not meant to query the Amadeus API themselves.
Due to the complexity and irregularity of the data returned by the Amadeus API,
These tests rely on manually checking the dumped files.
"""
from pathlib import Path

from pydantic import BaseModel

from fp.validation.models.amadeus.response import (
        AmadeusFlightsSearchResponseModel, AmadeusFlightsPricingResponseModel,
        AmadeusFlightConfirmResponseModel)

from .utils import dump_json_data, load_json_data


def spad_reserialize(fname: str, serializer: BaseModel):
    orig_data = load_json_data(fname, deserialize=False)
    deserialized_data = serializer.model_validate_json(orig_data)
    reserialized_data = deserialized_data.model_dump_json(indent=4,
                                                          by_alias=True,
                                                          exclude_unset=True)
    reserialized_fname = Path("reserialized").joinpath(fname)
    dump_json_data(
            reserialized_data,
            reserialized_fname,
            serialize=False,
    )


def main():
    # spad_reserialize("flights_search_one_way",
    #                  AmadeusFlightsSearchResponseModel)
    # spad_reserialize("flights_search_two_way",
    #                  AmadeusFlightsSearchResponseModel)
    # spad_reserialize("flight_pricing_one_way",
    #                  AmadeusFlightsPricingResponseModel)
    # spad_reserialize("flight_pricing_two_way",
    #                  AmadeusFlightsPricingResponseModel)
    # spad_reserialize("flight_booking_confirm_one_way",
    #                  AmadeusFlightConfirmResponseModel)
    # spad_reserialize("flight_booking_confirm_two_way",
    #                  AmadeusFlightConfirmResponseModel)
    # spad_reserialize("flight_booking_confirm_switch_id",
    #                  AmadeusFlightConfirmResponseModel)
    pass
