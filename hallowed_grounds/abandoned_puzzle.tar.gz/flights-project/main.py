from sys import argv

from fp.api import app


def init_scratchpad():
    import scratchpad
    if "--shell" in argv:
        import code
        import importlib
        import readline

        def run():
            importlib.reload(scratchpad)
            scratchpad.run()

        variables = globals().copy()
        variables.update(locals())
        shell = code.InteractiveConsole(variables)
        shell.interact()
    else:
        scratchpad.run()


def main():
    print("Invocation argument list:", argv)
    if "scratchpad" in argv:
        init_scratchpad()


if __name__ == '__main__':
    main()
