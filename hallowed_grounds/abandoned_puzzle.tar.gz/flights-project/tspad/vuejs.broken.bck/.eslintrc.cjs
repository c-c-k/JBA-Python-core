/* eslint-env node */
require("@rushstack/eslint-patch/modern-module-resolution");

module.exports = {
  root: true,
  // env: {
  //   browser: true,
  //   es2021: true,
  // },
  extends: [
    "plugin:vue/vue3-recommended",
    "eslint:recommended",
    // "standard-with-typescript",
    "prettier",
    "@vue/eslint-config-prettier/skip-formatting",
  ],
  // parser: "vue-eslint-parser",
  parserOptions: {
    ecmaVersion: "latest",
    // sourceType: "module",
    // parser: "@typescript-eslint/parser",
  },
  // overrides: [],
  // plugins: ["vue"],
  // rules: {},
};
