/* eslint-env node */
require("@rushstack/eslint-patch/modern-module-resolution");

module.exports = {
  root: true,
  extends: [
    "plugin:vue/vue3-recommended",
    "eslint:recommended",
    "prettier",
    "@vue/eslint-config-prettier/skip-formatting",
  ],
  parserOptions: {
    // ecmaVersion: "latest",
    ecmaVersion: 6,
    ecmaFeatures: {
      interfaces: true,
    },
  },
};
