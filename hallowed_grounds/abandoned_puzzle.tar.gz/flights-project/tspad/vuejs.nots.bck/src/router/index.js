import { createRouter, createWebHistory } from "vue-router";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      redirect: { name: "flightsSearch" },
    },
    {
      path: "/flights/search",
      name: "flightsSearch",
      component: () => import("../components/FlightsSearch.vue"),
    },
    {
      path: "/flights/detail/:flightId",
      name: "flightsDetail",
      component: () => import("../components/FlightsDetail.vue"),
    },
    {
      path: "/flights/booked",
      name: "flightsBooked",
      component: () => import("../components/FlightsBooked.vue"),
    },
    {
      path: "/auth/register",
      name: "authRegister",
      component: () => import("../components/AuthRegister.vue"),
    },
    {
      path: "/auth/login",
      name: "authLogin",
      component: () => import("../components/AuthLogin.vue"),
    },
    {
      path: "/auth/logout",
      name: "authLogout",
      component: () => import("../components/AuthLogout.vue"),
    },
    {
      path: "/users/:username",
      name: "usersDetail",
      component: () => import("../components/UsersDetail.vue"),
    },
  ],
});

export default router;
