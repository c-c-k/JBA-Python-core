let currentUser = null;
let login_token = null;

const REQUEST_ORIGIN = import.meta.env.VITE_FASTAPI_ORIGIN;
const AUTH_ROOT = "/api/auth";
const FLIGHTS_ROOT = "/api/flights";

const DEMO_USER_VUEJS = {
  username: "demouservuejs",
  firstName: "Demo",
  lastName: "User VueJs",
  email: "demouservuejs@example.com",
  password1: "secret",
  password2: "secret",
};

export async function getWelcomeMessage() {
  const requestHeaders = new Headers();
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    credentials: "include",
    refererPolicy: "no-referrer",
  };
  const requestURL = `${REQUEST_ORIGIN}/api`;
  const request = new Request(requestURL, requestOptions);
  try {
    console.log(request);
    const response = await fetch(request);
    console.log(response);
    return await response.text();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function postRegister(requestJson) {
  const requestURL = `${REQUEST_ORIGIN}${AUTH_ROOT}/register`;
  const requestHeaders = new Headers({ "Content-Type": "application/json" });
  const payload = JSON.stringify(requestJson);
  const requestOptions = {
    method: "POST",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
    body: payload,
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function postLogin(requestJson) {
  const requestURL = `${REQUEST_ORIGIN}${AUTH_ROOT}/token`;
  const requestHeaders = new Headers({
    "Content-Type": "application/x-www-form-urlencoded",
  });
  const payload = new URLSearchParams(requestJson);
  const requestOptions = {
    method: "POST",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
    body: payload,
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    const json_data = await response.json();
    return json_data;
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function getUserDetails(token) {
  const requestURL = `${REQUEST_ORIGIN}${AUTH_ROOT}/users/me`;
  const requestHeaders = new Headers({
    "Content-Type": "application/json",
    Authorization: "Bearer " + token,
  });
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function getFlightsSearch(requestJson) {
  const params = new URLSearchParams(requestJson);
  const requestURL = `${REQUEST_ORIGIN}${FLIGHTS_ROOT}/search?${params}`;
  const requestHeaders = new Headers();
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function demoGetFlightDetails() {
  const flightId = "64e9f80cf794a65bd30543d0";
  const requestURL = `${REQUEST_ORIGIN}${FLIGHTS_ROOT}/detail/${flightId}`;
  const requestHeaders = new Headers();
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
  };
  const request = new Request(requestURL, requestOptions);
  try {
    const response = await fetch(request);
    return await response.text();
    // return await requestURL
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function demoBookFlight() {
  await postLogin();
  const requestURL = `${REQUEST_ORIGIN}${FLIGHTS_ROOT}/book`;
  const requestHeaders = new Headers({
    "Content-Type": "application/json",
    Authorization: "Bearer " + login_token,
  });
  const data = { id: "64e9f80cf794a65bd30543d0" };
  const requestOptions = {
    method: "POST",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
    body: JSON.stringify(data),
  };
  const request = new Request(requestURL, requestOptions);
  try {
    const response = await fetch(request);
    return await response.text();
    // return await requestURL
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function getFlights() {
  return "Test Message";
  // return await getWelcomeMessage();
  // return await postRegister();
  // return await getDemoUserMe();
  // return await postLogin();
  // return await demoFlightsSearch();
  // return await demoGetFlightDetails();
  // return await demoBookFlight();
}
