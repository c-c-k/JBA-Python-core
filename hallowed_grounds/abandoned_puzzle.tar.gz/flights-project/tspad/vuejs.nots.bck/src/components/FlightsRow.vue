<script setup>
import { inject, ref, PropType } from "vue";

interface BaseFlightInfo = {
    id: { type: String, default: "" },
    origin: { type: String, default: "" },
    destination: { type: String, default: "" },
    departureDate: { type: String, default: "" },
    returnDate: { type: String, default: "" },
    price: { type: String, default: "" },
    currency: { type: String, default: "" },
};

const props = defineProps({
rowIndex: { type: Number, required: true },
flightData: Object as PropType<BaseFlightInfo>,
})
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Departure date: <input v-model="departure_date" type="date" /></label>
  <label>Return date: <input v-model="return_date" type="date" /></label>
  <label>Origin: <input v-model="origin" /></label>
  <label>Destination: <input v-model="destination" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="searchFlights">Search</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
