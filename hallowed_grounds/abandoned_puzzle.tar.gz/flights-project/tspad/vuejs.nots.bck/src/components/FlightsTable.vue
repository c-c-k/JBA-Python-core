<script setup>
import { useRouter } from "vue-router";
import { inject, ref } from "vue";

const router = useRouter();
const flights = inject("flights");

const origin = ref();
const destination = ref();
const departure_date = ref();
const return_date = ref();

const message = ref();

function createRequestJson() {
  return {
  origin: origin.value,
  destination: destination.value,
  departure_date: departure_date.value,
  return_date: return_date.value,
  };
}

function cacheFlightsInfo(flightsJson) {
  setFlights(flightsJson);
}

async function searchFlights() {
  message.value = "Loading flight data...";
  const requestJson = createRequestJson();
  const response = await getFlightsSearch(requestJson);
  if (response.accessToken) {
    cacheFlightsInfo(response);
    message.value = null;
  } else {
    message.value = response;
  }
}

function clearForm() {
  origin.value = null;
  destination.value = null;
  departure_date.value = null;
  return_date.value = null;
}
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Departure date: <input v-model="departure_date" type="date" /></label>
  <label>Return date: <input v-model="return_date" type="date" /></label>
  <label>Origin: <input v-model="origin" /></label>
  <label>Destination: <input v-model="destination" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="searchFlights">Search</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->

