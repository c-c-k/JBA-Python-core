<script setup>
import { useRouter } from "vue-router";
import { inject } from "vue";

const router = useRouter();
const setCurrentUser = inject("setCurrentUser");
const setAuthToken = inject("setAuthToken");

function logout() {
  setCurrentUser(null);
  setAuthToken(null);
  router.push({ name: "flightsSearch" });
}

logout();
</script>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
