<script setup>
import { useRouter } from "vue-router";
import { inject, ref } from "vue";
import { postLogin } from "../utils.js";

const router = useRouter();
const setCurrentUser = inject("setCurrentUser");
const setAuthToken = inject("setAuthToken");

const username = ref("");
const password = ref("");

const message = ref();

function createLoginJson() {
  return {
    username: username.value,
    password: password.value,
  };
}

function cacheLoginInfo(token) {
  setCurrentUser(username);
  setAuthToken(token);
}

async function login() {
  message.value = "proccessing...";
  const loginJson = createLoginJson();
  const result = await postLogin(loginJson);
  if (result.accessToken) {
    cacheLoginInfo(result.accessToken);
    router.push({ name: "flightsSearch" });
  } else {
    message.value = result;
  }
}

function clearForm() {
  username.value = "";
  password.value = "";
  message.value = "";
}
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Username: <input v-model="username" /></label>
  <label>Password: <input v-model="password" type="password" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="login">Login</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
