<script setup>
</script>

<template>
<p> placeholder </p>
</template>
