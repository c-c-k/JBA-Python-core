from sqlalchemy import text, insert

from jormungand.core.db import (
    get_db_connection, get_db_engine, UserRole, init_db, get_table)
from tests.dataset import insert_dataset, DATASET_VALID


def test_table_reflection():
    tables = get_tables()
    # print(tables)
    print(type(tables['users']))
    print(type(tables['users'].columns))
    print(tuple(column.name for column in tables['users'].columns))


def test_insert():
    init_db()
    users_table = get_table('users')
    # with get_db_connection() as conn:
        # conn.execute(
    stmt = insert(users_table).values(
            {
                'id': 51,
                'user_role': int(UserRole.CUSTOMER),
                'username': 'customer_user_1',
                'password': 'pass',
                'email': 'customer_user_1@email_1.com',
                'avatar_url': 'user_avatars/customer_user_1.png',
                'pinky': 'user_avatars/customer_user_1.png',
            }
        ).compile(get_db_engine())
    print(stmt)


# test_init_db_init_roles(get_db_connection):
# test_insert_dataset():
# test_table_reflection()
# test_insert()
