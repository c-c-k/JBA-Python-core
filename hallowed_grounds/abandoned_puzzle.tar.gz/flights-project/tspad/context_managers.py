import contextlib


class demo_object:
    demo_attribute = "demo_object demo_attribute"

@contextlib.contextmanager
def cmanager_1(*args, **kwargs):
    print('contextmanager args:')
    print(args, kwargs)
    print('context manager start')
    yield demo_object()
    print('context manager exit')
    

def use_cmanager1_with():
    print('using cmanager_1 as with')
    with cmanager_1() as cmanager:
        print(cmanager.demo_attribute)
    print('--------------------')
    

@cmanager_1
def use_cmanager1_decorator(*args, **kwargs):
    print('using cmanager_1 as decorator')
    print(args, kwargs)
    print('--------------------')


use_cmanager1_with()
use_cmanager1_decorator()
