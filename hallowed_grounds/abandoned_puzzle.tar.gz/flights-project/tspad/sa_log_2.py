from sqlalchemy import text

from jormungand.core.logging import get_logger
from jormungand.core.db import get_db_connection

logger = get_logger(__name__)
sa_logger = get_logger('sqlalchemy')

logger.debug('test message')
with get_db_connection() as conn:
    conn.execute(text('select 1 = 2'))
print(sa_logger.level)
print(sa_logger.handlers)
print(get_logger('root').handlers)
print(get_logger('root').name)
