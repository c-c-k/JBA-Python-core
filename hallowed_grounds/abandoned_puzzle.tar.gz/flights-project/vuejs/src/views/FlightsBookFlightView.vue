<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";

import { requestBookFlight } from "@/interfaces/backend/flights.ts";
import { useFlightsStore } from "@/stores/flights.ts";
import { useAuthStore } from "@/stores/auth.ts";

import type { FlightsBookingRequest } from "@/models/interfaces/flights.ts";

const route = useRoute();
const router = useRouter();
const flights = useFlightsStore();
const auth = useAuthStore();

const message = ref("Loading...");

function createRequestJson(): FlightsBookingRequest {
  return {
    id: route.params.flightId,
  };
}
async function bookFlight() {
  const flightId = route.params.flightId;
  if (flightId in Object.keys(flights.cachedBookedFlights)) {
    router.push({ name: "flightsBooked" });
  }
  message.value = `Loading...`;
  const requestJson: FlightsBookingRequest = createRequestJson();
  const responseJson = await requestBookFlight(auth.authToken, requestJson);
  if (responseJson.type == "flight-booking-info") {
    flights.cachedBookedFlights[flightId] = responseJson.data;
    message.value = null;
    router.push({ name: "flightsBooked" });
  } else {
    message.value = responseJson;
  }
}

onMounted(bookFlight);
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <div>
    <button
      @click="
        $router.push({
          name: 'FlightDetails',
          params: { flightId: $route.params.flightId },
        })
      "
    >
      Back
    </button>
  </div>
</template>
