<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

import { requestFlightDetails } from "@/interfaces/backend/flights.ts";
import { useFlightsStore } from "@/stores/flights.ts";
import { useAuthStore } from "@/stores/auth.ts";

import type { FlightDetails } from "@/models/interfaces/flights.ts";

const route = useRoute();
const flights = useFlightsStore();
const auth = useAuthStore();

const flight = ref<FlightDetails>();

const message = ref("Loading...");

async function applyFlightDetails() {
  const flightId = route.params.flightId;
  if (flightId in Object.keys(flights.cachedFlights)) {
    flight.value = flights.cachedFlights.value[flightId];
    return;
  }
  message.value = `Loading...`;
  const responseJson: FlightDetails = await requestFlightDetails(flightId);
  if (responseJson.id == flightId) {
    flights.cachedFlights[flightId] = responseJson;
    flight.value = responseJson;
    message.value = null;
  } else {
    message.value = responseJson;
  }
}

onMounted(applyFlightDetails);
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <div v-if="flight">
    <ul>
      <li><strong>Origin:</strong> {{ flight.origin }}</li>
      <li><strong>Destination:</strong> {{ flight.destination }}</li>
      <li><strong>Departure Date:</strong> {{ flight.departureDate }}</li>
      <li v-if="flight.returnDate">
        <strong>Return Date:</strong> {{ flight.returnDate }}
      </li>
      <li>
        <strong>Price:</strong> {{ `${flight.price} ${flight.currency}` }}
      </li>
    </ul>
  </div>
  <div>
    <button @click="$router.push({ name: 'flightsSearch' })">Back</button>
    <button
      :disabled="auth.username == null"
      @click="
        $router.push({
          name: 'flightsBookFlight',
          params: { flightId: flight.id },
        })
      "
    >
      Book Flight
    </button>
  </div>
</template>
