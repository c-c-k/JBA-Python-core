<script setup lang="ts">
/* import { ref, onMounted } from "vue"; */
import { ref } from "vue";
/* import { useRoute } from "vue-router"; */

/* import { requestFlightDetails } from "@/interfaces/backend/flights.ts"; */
import { useFlightsStore } from "@/stores/flights.ts";
/* import { useAuthStore } from "@/stores/auth.ts"; */

/* import type { FlightDetails } from "@/models/interfaces/flights.ts"; */

/* const route = useRoute(); */
const flights = useFlightsStore();
/* const auth = useAuthStore(); */

/* const flight = ref<FlightDetails>(); */

const message = ref();

/* async function applyFlightDetails() { */
/*   const flightId = route.params.flightId; */
/*   if (flightId in Object.keys(flights.cachedFlights)) { */
/*     flight.value = flights.cachedFlights.value[flightId]; */
/*     return; */
/*   } */
/*   message.value = `Loading...`; */
/*   const responseJson: FlightDetails = await requestFlightDetails(flightId); */
/*   if (responseJson.id == flightId) { */
/*     flights.cachedFlights[flightId] = responseJson; */
/*     flight.value = responseJson; */
/*     message.value = null; */
/*   } else { */
/*     message.value = responseJson; */
/*   } */
/* } */

/* onMounted(applyFlightDetails); */
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <div
    v-for="(bookedFlight, flightId) in flights.cachedBookedFlights"
    :key="flightId"
  >
    <br />
    <span> {{ " Flight Information: " }} </span>
    <br />
    <br />
    <span> {{ bookedFlight.flightInfo.origin }} </span>
    <span> {{ " -> " }} </span>
    <span> {{ bookedFlight.flightInfo.destination }} </span>
    <span> {{ ", Depart on: " }} </span>
    <span> {{ bookedFlight.flightInfo.departureDate }} </span>
    <span v-if="bookedFlight.flightInfo.returnDate">
      {{ ", Return on: " }}
      {{ bookedFlight.flightInfo.returnDate }}
    </span>
    <span>
      {{ ", Cost: " }}
      {{ bookedFlight.flightInfo.price }}
      {{ bookedFlight.flightInfo.currency }}
    </span>
    <br />
    <br />
    <span> {{ " Order Information: " }} </span>
    <br />
    <br />
    <span> {{ "Reference: " }} </span>
    <span> {{ bookedFlight.orderInfo.reference }} </span>
    <span> {{ ", Creation Date: " }} </span>
    <span> {{ bookedFlight.orderInfo.creationDate }} </span>
    <span> {{ ", Origin System Code: " }} </span>
    <span> {{ bookedFlight.orderInfo.originSystemCode }} </span>
    <br />
    <br />
    <br />
  </div>
</template>
