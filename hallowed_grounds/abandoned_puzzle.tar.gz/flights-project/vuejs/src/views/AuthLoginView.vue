<script setup lang="ts">
import { useRouter } from "vue-router";
import { ref } from "vue";

import { requestLogin } from "@/interfaces/backend/auth.ts";
import { useAuthStore } from "@/stores/auth.ts";

import type { LoginRequest } from "@/models/interfaces/auth.ts";

const auth = useAuthStore();
const router = useRouter();

const username = ref("");
const password = ref("");

const message = ref();

function createRequestJson(): LoginRequest {
  return {
    username: username.value,
    password: password.value,
  };
}

async function login() {
  message.value = "proccessing...";
  const requestJson: LoginRequest = createRequestJson();
  const response = await requestLogin(requestJson);
  if (response.accessToken) {
    auth.cacheLogin(username, response.accessToken);
    router.push({ name: "flightsSearch" });
    message.value = null;
  } else {
    message.value = response;
  }
}

function clearForm() {
  username.value = "";
  password.value = "";
  message.value = null;
}
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Username: <input v-model="username" /></label>
  <label>Password: <input v-model="password" type="password" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="login">Login</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
