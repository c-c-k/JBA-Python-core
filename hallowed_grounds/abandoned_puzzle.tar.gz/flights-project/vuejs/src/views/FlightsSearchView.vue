<script setup lang="ts">
import FlightsSearchForm from "@/components/flights/search/FlightsSearchForm.vue";
import FlightsTable from "@/components/flights/search/FlightsTable.vue";
import FlightsTabs from "@/components/flights/search/FlightsTabs.vue";
import { useFlightsStore } from "@/stores/flights.ts";

const flights = useFlightsStore();
</script>

<template>
  <FlightsTabs/>
  <FlightsTable v-if="flights.currentSearch !== null" />
  <FlightsSearchForm v-else />
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
