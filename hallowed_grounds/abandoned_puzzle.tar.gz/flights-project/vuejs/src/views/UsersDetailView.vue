<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";

import { requestUserDetails } from "@/interfaces/backend/auth.ts";
import { useAuthStore } from "@/stores/auth.ts";
import { useUserStore } from "@/stores/user.ts";

import type { User } from "@/models/interfaces/user.ts";

const router = useRouter();

const auth = useAuthStore();
const user = useUserStore();

const message = ref("Loading...");

async function applyUserDetails() {
  if (!auth.username) {
    router.push({ name: "authLogin" });
  }
  message.value = "Loading...";
  const responseJson: User = await requestUserDetails(auth.authToken);
  if (responseJson.username == auth.username.value) {
    user.cacheUser(responseJson);
    message.value = null;
  } else {
    message.value = responseJson;
  }
}

onMounted(applyUserDetails);
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <div>
    <ul>
      <li><strong>Username:</strong> {{ user.username }}</li>
      <li><strong>First Name:</strong> {{ user.firstName }}</li>
      <li><strong>Last Name:</strong> {{ user.lastName }}</li>
      <li><strong>Email:</strong> {{ user.email }}</li>
    </ul>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
