<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";

import { useAuthStore } from "@/stores/auth.ts";
import { useUserStore } from "@/stores/user.ts";

const auth = useAuthStore();
const user = useUserStore();

const router = useRouter();

const message = ref("Logging Out...");

function logout() {
  auth.clearCachedLogin();
  user.clearCachedUser();
  router.push({ name: "flightsSearch" });
}

logout();
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
</template>
<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
