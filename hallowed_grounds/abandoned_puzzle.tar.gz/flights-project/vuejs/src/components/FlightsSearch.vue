<script setup>
import { useRouter } from "vue-router";
import { inject, ref } from "vue";
import { getFlightsSearch } from "../utils.js";

const router = useRouter();
const flights = inject("flights");
const setFlights = inject("setFlights");

const origin = ref();
const destination = ref();
const departure_date = ref();
const return_date = ref();

const message = ref();

function createSearchParams() {
  return {
  origin: origin.value,
  destination: destination.value,
  departure_date: departure_date.value,
  return_date: return_date.value,
  };
}

function cacheFlightsInfo(flightsJson) {
  setFlights(flightsJson);
}

async function login() {
  message.value = "proccessing...";
  const loginJson = createLoginJson();
  const result = await postLogin(loginJson);
  if (result.accessToken) {
    persistLoginInfo(result.accessToken);
    router.push({ name: "flightsSearch" });
  } else {
    message.value = result;
  }
}

function clearForm() {
  username.value = "";
  password.value = "";
  message.value = "";
}
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Username: <input v-model="username" /></label>
  <label>Password: <input v-model="password" type="password" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="login">Login</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->

