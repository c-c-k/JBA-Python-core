<script setup lang="ts">
import { ref } from "vue";

import { requestFlightsSearch } from "@/interfaces/backend/flights.ts";
import { useFlightsStore } from "@/stores/flights.ts";

import type {
  FlightsSearchResponse,
  FlightsSearchRequest,
} from "@/models/interfaces/flights.ts";

const flights = useFlightsStore();

const origin = ref("TLV");
const destination = ref("LON");
const departureDate = ref("2023-09-14");
const returnDate = ref("2023-09-19");

const message = ref();

function createRequestJson(): FlightsSearchRequest {
  return {
    origin: origin.value,
    destination: destination.value,
    departureDate: departureDate.value,
    returnDate: returnDate.value,
  };
}

async function searchFlights() {
  message.value = "Loading flight data...";
  const requestJson: FlightsSearchRequest = createRequestJson();
  const responseJson: FlightsSearchResponse =
    await requestFlightsSearch(requestJson);
  if (responseJson.type == "flight-offers-info") {
    flights.cacheSearch(requestJson, responseJson);
    message.value = null;
  } else {
    message.value = responseJson;
  }
}

function clearForm() {
  origin.value = null;
  destination.value = null;
  departure_date.value = null;
  return_date.value = null;
}
</script>

<template>
  <div>
    <h3 v-show="message">{{ message }}</h3>
  </div>
  <label>Departure date: <input v-model="departureDate" type="date" /></label>
  <label>Return date: <input v-model="returnDate" type="date" /></label>
  <label>Origin: <input v-model="origin" /></label>
  <label>Destination: <input v-model="destination" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="searchFlights">Search</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
