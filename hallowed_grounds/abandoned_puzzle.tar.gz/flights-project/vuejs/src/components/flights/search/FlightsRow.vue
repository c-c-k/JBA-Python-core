<script setup lang="ts">
import { PropType } from "vue";
import { useRouter } from "vue-router";

import type { FlightOffer } from "@/models/interfaces/flights.ts";

const router = useRouter();

const props = defineProps({
  rowIndex: { type: Number, required: true },
  flightOffer: { type: Object as PropType<FlightOffer>, required: true },
});

function showDetails() {
  router.push({
    name: "flightsDetail",
    params: { flightId: props.flightOffer.id },
  });
}
</script>

<template>
  <tr>
    <th>{{ props.rowIndex }}</th>
    <td>{{ props.flightOffer.origin }}</td>
    <td>{{ props.flightOffer.destination }}</td>
    <td>{{ props.flightOffer.departureDate }}</td>
    <td>{{ props.flightOffer.returnDate }}</td>
    <td>{{ props.flightOffer.price }} {{ flightOffer.currency }}</td>
    <td><button @click="showDetails">Details</button></td>
  </tr>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
