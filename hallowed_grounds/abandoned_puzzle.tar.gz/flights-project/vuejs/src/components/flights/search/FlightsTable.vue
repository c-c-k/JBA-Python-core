<script setup lang="ts">
import { useFlightsStore } from "@/stores/flights.ts";

import FlightsRow from "./FlightsRow.vue";

const flights = useFlightsStore();

</script>

<template>
  <table>
    <thead>
      <tr>
        <th></th>
        <th>Origin</th>
        <th>Destination</th>
        <th>Departure Date</th>
        <th>Return Date</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <FlightsRow
        v-for="(flightOffer, rowIndex) in flights.currentSearch.flightOffers"
        :key="flightOffer.id"
        :row-index="rowIndex"
        :flight-offer="flightOffer"
      />
    </tbody>
  </table>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
