<script setup lang="ts">
import { useFlightsStore } from "@/stores/flights.ts";

const flights = useFlightsStore();
</script>

<template>
  <div>
    <template v-for="(cachedSearch, id) in flights.cachedSearches" :key="id">
      <button @click="flights.currentSearchId = id">
        {{ cachedSearch.title }}
      </button>
      <button @click="flights.RemoveCachedSearch(id)">X</button>
    </template>
    <button @click="flights.currentSearchId = null">New Search</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
