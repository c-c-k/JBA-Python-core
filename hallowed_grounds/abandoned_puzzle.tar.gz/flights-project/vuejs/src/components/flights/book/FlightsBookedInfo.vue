<script setup lang="ts">
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Username: <input v-model="username" /></label>
  <label>Password: <input v-model="password" type="password" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="login">Login</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
