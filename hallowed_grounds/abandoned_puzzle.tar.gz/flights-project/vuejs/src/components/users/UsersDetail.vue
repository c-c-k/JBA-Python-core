<script setup lang="ts">
import { inject, ref, onMounted } from "vue";
import { getUserDetails } from "../utils.js";

const currentUser = inject("currentUser");
const authToken = inject("authToken");

const username = ref("");
const firstName = ref("");
const lastName = ref("");
const email = ref("");

const message = ref("Loading...");

function parseUserJson(userJson) {
  username.value = userJson.username;
  firstName.value = userJson.firstName;
  lastName.value = userJson.lastName;
  email.value = userJson.email;
}

async function applyUserDetails() {
  message.value = "Loading...";
  const result = await getUserDetails(authToken.value);
  console.log(currentUser.value);

  console.log(result.username);
  if (result.username == currentUser.value) {
    parseUserJson(result);
    message.value = null;
  } else {
    parseUserJson(result);
    message.value = result;
  }
}

onMounted(applyUserDetails);
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <div>
    <ul>
      <li><strong>Username:</strong> {{ username }}</li>
      <li><strong>First Name:</strong> {{ firstName }}</li>
      <li><strong>Last Name:</strong> {{ lastName }}</li>
      <li><strong>Email:</strong> {{ email }}</li>
    </ul>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
