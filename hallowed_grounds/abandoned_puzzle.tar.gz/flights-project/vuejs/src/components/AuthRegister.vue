<script setup>
import { useRouter } from "vue-router";
import { ref } from "vue";
import { postRegister } from "../utils.js";

const router = useRouter();

const username = ref("");
const firstName = ref("");
const lastName = ref("");
const email = ref("");
const password1 = ref("");
const password2 = ref("");

const message = ref();

function createUserJson() {
  return {
    username: username.value,
    firstName: firstName.value,
    lastName: lastName.value,
    email: email.value,
    password1: password1.value,
    password2: password2.value,
  };
}

async function register() {
  message.value = "proccessing...";
  const userJson = createUserJson();
  const result = await postRegister(userJson);
  if (result.success) {
    router.push({ name: "login" });
  } else {
    message.value = result;
  }
}

function clearForm() {
  username.value = "";
  firstName.value = "";
  lastName.value = "";
  email.value = "";
  password1.value = "";
  password2.value = "";
  message.value = "";
}
</script>

<template>
  <div>
    <h3 v-if="message">{{ message }}</h3>
  </div>
  <label>Username: <input v-model="username" /></label>
  <label>Name: <input v-model="firstName" /></label>
  <label>Surname: <input v-model="lastName" /></label>
  <label>Email: <input v-model="email" type="email" /></label>
  <label>Password: <input v-model="password1" type="password" /></label>
  <label>Password: <input v-model="password2" type="password" /></label>

  <div class="buttons">
    <button @click="clearForm">Clear Form</button>
    <button @click="register">Register</button>
  </div>
</template>

<style>
* {
  font-size: inherit;
}

input {
  display: block;
  margin-bottom: 10px;
}
</style>

<!--
Attributions:

https://eugenkiss.github.io/7guis/tasks/#crud
-->
