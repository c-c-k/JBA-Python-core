import { computed, reactive, ref, shallowRef, triggerRef } from "vue";
import { defineStore } from "pinia";

import type {
  CachedFlightsSearch,
  FlightsSearchResponse,
  FlightsSearchRequest,
  FlightDetails,
} from "@/models/interfaces/flights.ts";

export const useFlightsStore = defineStore("flights", () => {
  const cachedSearches = shallowRef({});
  const cachedFlights = reactive({});
  const cachedBookedFlights = reactive({});
  const currentSearchId = ref<String | null>(null);

  const currentSearch = computed(() =>
    currentSearchId.value != null
      ? cachedSearches.value[currentSearchId.value]
      : null,
  );

  // function cacheFlight(
  //   responseJson: FlightDetails,
  // ) {
  //   cachedFlights.value[responseJson.id] = responseJson;
  // }

  function cacheSearch(
    requestJson: FlightsSearchRequest,
    responseJson: FlightsSearchResponse,
  ) {
    const id = `${requestJson.origin}${requestJson.destination}${
      requestJson.departureDate
    }${requestJson.departureDate ? requestJson.returnDate : ""}`;
    const title = `${requestJson.origin}->${requestJson.destination}`;
    cachedSearches.value[id] = {
      id: id,
      title: title,
      requestJson: requestJson,
      flightOffers: responseJson.flightOffers,
    };
    triggerRef(cachedSearches);
    currentSearchId.value = id;
  }

  function RemoveCachedSearch(id: String) {
    if (!(id in cachedSearches.value)) {
      return;
    }
    const keys = Object.keys(cachedSearches.value);
    if (keys.length == 1) {
      currentSearchId.value = null;
    } else {
      const deleteIndex = keys.indexOf(id);
      const currentIndex = keys.indexOf(currentSearchId.value);
      if (deleteIndex === currentIndex) {
        const newIndex = currentIndex == 0 ? 1 : currentIndex - 1;
        currentSearchId.value = keys[newIndex];
      }
    }
    delete cachedSearches.value[id];
    triggerRef(cachedSearches);
    console.log(currentSearchId);
  }

  return {
    cachedSearches,
    currentSearchId,
    currentSearch,
    cacheSearch,
    RemoveCachedSearch,
    cachedFlights,
    cachedBookedFlights,
  };
});
