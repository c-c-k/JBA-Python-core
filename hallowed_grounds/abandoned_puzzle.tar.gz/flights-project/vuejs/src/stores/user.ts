import { defineStore } from "pinia";
import { ref } from "vue";

import type { User } from "@/models/interfaces/user.ts";

export const useUserStore = defineStore("user", () => {
  const username = ref("");
  const firstName = ref("");
  const lastName = ref("");
  const email = ref("");

  function cacheUser(newUser: User) {
    username.value = newUser.username;
    firstName.value = newUser.firstName;
    lastName.value = newUser.lastName;
    email.value = newUser.email;
  }

  function clearCachedUser() {
    username.value = "";
    firstName.value = "";
    lastName.value = "";
    email.value = "";
  }

  return { username, firstName, lastName, email, cacheUser, clearCachedUser };
});
