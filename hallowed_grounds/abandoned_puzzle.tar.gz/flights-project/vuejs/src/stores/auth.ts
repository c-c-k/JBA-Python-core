import { ref } from "vue";
import { defineStore } from "pinia";

export const useAuthStore = defineStore("auth", () => {
  const username: String = ref(null);
  const authToken: String = ref(null);
 
  function cacheLogin(newUsername: String, newAuthToken: String) {
    username.value = newUsername;
    authToken.value = newAuthToken;
  }

  function clearCachedLogin() {
    username.value = null;
    authToken.value = null;
  }

  return { username, authToken, cacheLogin, clearCachedLogin };
});
