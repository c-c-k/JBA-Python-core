import type { RegistrationRequest } from "@/models/interfaces/auth.ts";

const REQUEST_ORIGIN = import.meta.env.VITE_FASTAPI_ORIGIN;
const AUTH_ROOT = "/api/auth";

export async function requestRegister(requestJson: RegistrationRequest) {
  const requestURL = `${REQUEST_ORIGIN}${AUTH_ROOT}/register`;
  const requestHeaders = new Headers({ "Content-Type": "application/json" });
  const payload = JSON.stringify(requestJson);
  const requestOptions = {
    method: "POST",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
    body: payload,
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function requestLogin(requestJson) {
  const requestURL = `${REQUEST_ORIGIN}${AUTH_ROOT}/token`;
  const requestHeaders = new Headers({
    "Content-Type": "application/x-www-form-urlencoded",
  });
  const payload = new URLSearchParams(requestJson);
  const requestOptions = {
    method: "POST",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
    body: payload,
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    const json_data = await response.json();
    // console.log(json_data);
    return json_data;
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function requestUserDetails(authToken: String) {
  const requestURL = `${REQUEST_ORIGIN}${AUTH_ROOT}/users/me`;
  const requestHeaders = new Headers({
    "Content-Type": "application/json",
    Authorization: "Bearer " + authToken,
  });
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}
