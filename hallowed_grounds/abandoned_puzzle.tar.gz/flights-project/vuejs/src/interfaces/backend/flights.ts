import type {
  FlightsSearchRequest,
  FlightsBookingRequest,
  FlightsSearchResponse,
} from "@/models/interfaces/flights.ts";

const REQUEST_ORIGIN = import.meta.env.VITE_FASTAPI_ORIGIN;
const FLIGHTS_ROOT = "/api/flights";

export async function requestFlightsSearch(
  requestJson: FlightsSearchRequest,
): FlightsSearchResponse {
  const params = new URLSearchParams(requestJson);
  const requestURL = `${REQUEST_ORIGIN}${FLIGHTS_ROOT}/search?${params}`;
  const requestHeaders = new Headers();
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function requestFlightDetails(flightId: String) {
  // const flightId = "64e9f80cf794a65bd30543d0";
  // const flightId = requestJson.flightId;
  const requestURL = `${REQUEST_ORIGIN}${FLIGHTS_ROOT}/detail/${flightId}`;
  const requestHeaders = new Headers();
  const requestOptions = {
    method: "GET",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}

export async function requestBookFlight(
  authToken: String,
  requestJson: FlightsBookingRequest,
) {
  const requestURL = `${REQUEST_ORIGIN}${FLIGHTS_ROOT}/book`;
  const requestHeaders = new Headers({
    "Content-Type": "application/json",
    Authorization: "Bearer " + authToken,
  });
  const payload = JSON.stringify(requestJson);
  const requestOptions = {
    method: "POST",
    headers: requestHeaders,
    mode: "cors",
    cache: "default",
    redirect: "follow",
    refererPolicy: "no-referrer",
    body: payload,
  };
  const request = new Request(requestURL, requestOptions);
  try {
    // console.log(request);
    const response = await fetch(request);
    // console.log(response);
    return await response.json();
  } catch (err) {
    return "An error has occurred:" + err;
  }
}
