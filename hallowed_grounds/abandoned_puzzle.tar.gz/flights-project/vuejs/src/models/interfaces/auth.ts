import type { User } from "./user.ts";

export interface RegistrationRequest extends User {
  password1: String;
  password2: String;
}

export interface LoginRequest {
  username: String;
  password: String;
}
