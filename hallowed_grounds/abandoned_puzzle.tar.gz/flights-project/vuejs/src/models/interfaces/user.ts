export interface User {
  username: String;
  firstName: String;
  lastName: String;
  email: String;
}
