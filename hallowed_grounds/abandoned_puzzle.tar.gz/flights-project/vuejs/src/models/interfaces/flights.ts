export interface BaseFlightsSearch {
  origin: String;
  destination: String;
  departureDate: String;
  returnDate: String;
}

export interface FlightsSearchRequest extends BaseFlightsSearch {}

export interface FlightsBookingRequest {
  id: String;
}

export interface FlightOffer {
  id: String;
  origin: String;
  destination: String;
  departureDate: String;
  returnDate?: String;
  price: String;
  currency: String;
}

export interface FlightDetails extends FlightOffer {}

export interface FlightsSearchResponse {
  type: String;
  flightOffers: FlightOffer[];
}

export interface CachedFlightsSearch {
  id;
  title;
  requestJson: FlightsSearchRequest;
  flightOffers: FlightOffer[];
}
