API
===

.. autosummary::
    :recursive:
    :toctree: API

    fp
    fp.utils
