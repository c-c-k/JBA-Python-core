from fp.bll import find_airports


def test_find_airports():
    find_airports('a')
