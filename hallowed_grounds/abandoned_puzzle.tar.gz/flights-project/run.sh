#!/usr/bin/env bash

run_command="$1"

case "$run_command" in
        ( "venv" )
            . ./.venv/bin/activate
            ;;
        ( "fastapi" | "uvicorn" )
            shift
            uvicorn --reload "$@" main:app
            ;;
        ( * )
            python3 main.py "$@"
            ;;
esac
