﻿jormungand
==========

.. automodule:: jormungand

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      main
   
   

   
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   jormungand.dal
   jormungand.utils

