from models import Teacher, Student, Course

# ==Populate the database with generic data==

# python datasets
teachers = (

)



def populate():
    pass

